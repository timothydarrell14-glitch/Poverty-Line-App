/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ActiveTab, Job, Program } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomeScreen } from './components/HomeScreen';
import { GetHelpScreen } from './components/GetHelpScreen';
import { DonorsScreen } from './components/DonorsScreen';
import { OrganisationsScreen } from './components/OrganisationsScreen';
import { ContactScreen } from './components/ContactScreen';
import {
  DonationModal,
  LoginModal,
  LiveChatModal,
  CallbackModal,
  JobDetailsModal,
  PartnerApplicationModal,
  InfoModal,
} from './components/Modals';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');

  // Modals state
  const [isDonateOpen, setIsDonateOpen] = useState(false);
  const [selectedProgramForDonation, setSelectedProgramForDonation] = useState<Program | null>(null);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isLiveChatOpen, setIsLiveChatOpen] = useState(false);
  const [isCallbackOpen, setIsCallbackOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isPartnerOpen, setIsPartnerOpen] = useState(false);
  const [isStoryOpen, setIsStoryOpen] = useState(false);
  const [isMethodologyOpen, setIsMethodologyOpen] = useState(false);
  const [isImpactReportOpen, setIsImpactReportOpen] = useState(false);

  const handleOpenDonateWithProgram = (program: Program) => {
    setSelectedProgramForDonation(program);
    setIsDonateOpen(true);
  };

  const handleOpenGeneralDonate = () => {
    setSelectedProgramForDonation(null);
    setIsDonateOpen(true);
  };

  const handleOpenHelpline = () => {
    const confirmed = window.confirm(
      '24/7 Helpline: 1-800-555-0199\n\nWould you like to copy the number or dial now?'
    );
    if (confirmed) {
      window.location.href = 'tel:18005550199';
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f7f9ff] text-[#181c20] selection:bg-[#005f6a] selection:text-white">
      {/* 1. Header Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenDonate={handleOpenGeneralDonate}
        onOpenLogin={() => setIsLoginOpen(true)}
      />

      {/* 2. Main Content Screens */}
      <main className="flex-grow pt-[72px]">
        {activeTab === 'home' && (
          <HomeScreen
            setActiveTab={setActiveTab}
            onOpenDonate={handleOpenGeneralDonate}
            onOpenStory={() => setIsStoryOpen(true)}
            onOpenMethodology={() => setIsMethodologyOpen(true)}
            onOpenPartner={() => setIsPartnerOpen(true)}
          />
        )}

        {activeTab === 'get-help' && (
          <GetHelpScreen
            onSelectJob={(job) => setSelectedJob(job)}
            onOpenLiveChat={() => setIsLiveChatOpen(true)}
            onOpenCallbackModal={() => setIsCallbackOpen(true)}
            onOpenHelpline={handleOpenHelpline}
          />
        )}

        {activeTab === 'donors' && (
          <DonorsScreen
            onSelectProgramForDonation={handleOpenDonateWithProgram}
            onOpenGeneralDonation={handleOpenGeneralDonate}
            onOpenImpactReport={() => setIsImpactReportOpen(true)}
          />
        )}

        {activeTab === 'organisations' && (
          <OrganisationsScreen
            onOpenPartnerApplication={() => setIsPartnerOpen(true)}
            onOpenLiveSimulation={() => {
              const el = document.getElementById('command-center-preview');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'contact' && <ContactScreen />}
      </main>

      {/* 3. Footer */}
      <Footer
        setActiveTab={setActiveTab}
        onOpenStory={() => setIsStoryOpen(true)}
        onOpenPartner={() => setIsPartnerOpen(true)}
        onOpenContact={() => {
          setActiveTab('contact');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* 4. Global Modals */}
      <DonationModal
        isOpen={isDonateOpen}
        onClose={() => {
          setIsDonateOpen(false);
          setSelectedProgramForDonation(null);
        }}
        selectedProgram={selectedProgramForDonation}
      />

      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />

      <LiveChatModal isOpen={isLiveChatOpen} onClose={() => setIsLiveChatOpen(false)} />

      <CallbackModal isOpen={isCallbackOpen} onClose={() => setIsCallbackOpen(false)} />

      <JobDetailsModal job={selectedJob} onClose={() => setSelectedJob(null)} />

      <PartnerApplicationModal isOpen={isPartnerOpen} onClose={() => setIsPartnerOpen(false)} />

      {/* Story Info Modal */}
      <InfoModal
        isOpen={isStoryOpen}
        onClose={() => setIsStoryOpen(false)}
        title="Our Story & Founding Vision"
        subtitle="Bridging the gap between surplus and human need with radical efficiency"
        content={
          <div className="space-y-4">
            <p>
              Poverty Line was founded on a simple realization: the greatest obstacle in poverty alleviation is not lack of generosity, but operational friction and fragmented logistics.
            </p>
            <p>
              Traditional aid models often lose up to 40% of their momentum in administrative overhead and delayed routing. By bringing real-time supply chain telemetry, open donor accountability, and respectful community-first intake systems under one roof, we restore dignity and accelerate delivery.
            </p>
            <div className="p-4 bg-[#f1f4f9] rounded-xl border border-[#e0e3e8]">
              <h5 className="font-heading font-bold text-[#005f6a] mb-1">Our Three Core Pillars:</h5>
              <ul className="list-disc list-inside space-y-1 text-xs">
                <li><strong>Radical Transparency:</strong> Every dollar and unit is tracked from donor handoff to final community delivery.</li>
                <li><strong>Dignity in Every Interaction:</strong> Support is delivered without stigma, empowering recipients through job opportunities and mutual aid.</li>
                <li><strong>Open Partner Infrastructure:</strong> Free logistics tools for regional non-profits to avoid duplicate work.</li>
              </ul>
            </div>
          </div>
        }
      />

      {/* Methodology Info Modal */}
      <InfoModal
        isOpen={isMethodologyOpen}
        onClose={() => setIsMethodologyOpen(false)}
        title="Our Sustainable Methodology"
        subtitle="How our adaptive resource model creates permanent resilience"
        content={
          <div className="space-y-4">
            <p>
              Instead of top-down aid drops that disrupt local markets, Poverty Line operates through an <strong>Adaptive Community Feedback Loop</strong>.
            </p>
            <p>
              1. <strong>Grassroots Demand Sensing:</strong> Local organizers and community forums identify exact shortages (such as infant formula, clean water wells, or digital resumes) in real time.
            </p>
            <p>
              2. <strong>Intelligent Routing:</strong> Dynamic delivery fleets and partner non-profits distribute resources with minimal fuel and zero warehousing delays.
            </p>
            <p>
              3. <strong>Long-Term Capacity Building:</strong> Each aid distribution point transitions into a self-sustaining training hub, connecting neighbors with dignified job opportunities and skill classes.
            </p>
          </div>
        }
      />

      {/* Impact Report Modal */}
      <InfoModal
        isOpen={isImpactReportOpen}
        onClose={() => setIsImpactReportOpen(false)}
        title="Annual Impact & Financial Transparency Report"
        subtitle="Audited operational metrics and program milestones"
        content={
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="p-3 bg-[#f1f4f9] rounded-xl">
                <div className="font-heading text-xl font-bold text-[#005f6a]">$2.4M+</div>
                <div className="text-[10px] text-[#6e797b]">Total Deployed Aid</div>
              </div>
              <div className="p-3 bg-[#f1f4f9] rounded-xl">
                <div className="font-heading text-xl font-bold text-[#376847]">94.2%</div>
                <div className="text-[10px] text-[#6e797b]">Direct-to-Program Ratio</div>
              </div>
              <div className="p-3 bg-[#f1f4f9] rounded-xl">
                <div className="font-heading text-xl font-bold text-[#953914]">38,000+</div>
                <div className="text-[10px] text-[#6e797b]">Clean Water Access</div>
              </div>
            </div>
            <p className="text-xs text-[#3e494a] leading-relaxed">
              Every month, certified third-party accounting firms review all supply receipts, warehouse logs, and donor disbursements. Our full IRS Form 990 filings and quarterly performance reviews are available freely to the public.
            </p>
          </div>
        }
      />
    </div>
  );
}

