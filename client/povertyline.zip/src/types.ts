export type ActiveTab = 'home' | 'get-help' | 'donors' | 'organisations' | 'contact';

export interface Job {
  id: string;
  title: string;
  type: 'Immediate' | 'Part-time' | 'Full-time' | 'Contract';
  description: string;
  fullDescription: string;
  location: string;
  salary: string;
  requirements: string[];
  postedAt: string;
}

export interface ForumTopic {
  id: string;
  title: string;
  content: string;
  author: string;
  authorRole?: string;
  timeAgo: string;
  category: 'Housing' | 'Food' | 'Employment' | 'Healthcare' | 'General';
  repliesCount: number;
  likes: number;
  comments: Array<{
    id: string;
    author: string;
    text: string;
    timeAgo: string;
  }>;
}

export interface Program {
  id: string;
  title: string;
  category: string;
  icon: string;
  colorType: 'primary' | 'secondary' | 'tertiary';
  description: string;
  fullStory: string;
  imageUrl: string;
  imageAlt: string;
  goal?: number;
  raised?: number;
  impactMetric: string;
}

export interface LogisticsLog {
  id: string;
  title: string;
  timestamp: string;
  type: 'delivery' | 'inventory' | 'volunteer' | 'route';
  status: 'completed' | 'warning' | 'info' | 'active';
  details?: string;
}

export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  role: string;
  organization: string;
  avatarUrl: string;
  avatarAlt: string;
}
