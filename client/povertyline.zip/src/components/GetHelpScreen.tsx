import React, { useState } from 'react';
import { Job, ForumTopic } from '../types';
import { HERO_IMAGES, INITIAL_JOBS, INITIAL_FORUM_TOPICS } from '../data/mockData';

interface GetHelpScreenProps {
  onSelectJob: (job: Job) => void;
  onOpenLiveChat: () => void;
  onOpenCallbackModal: () => void;
  onOpenHelpline: () => void;
}

export const GetHelpScreen: React.FC<GetHelpScreenProps> = ({
  onSelectJob,
  onOpenLiveChat,
  onOpenCallbackModal,
  onOpenHelpline,
}) => {
  const [jobs] = useState<Job[]>(INITIAL_JOBS);
  const [showAllJobs, setShowAllJobs] = useState(false);
  const [forumTopics, setForumTopics] = useState<ForumTopic[]>(INITIAL_FORUM_TOPICS);
  const [expandedTopicId, setExpandedTopicId] = useState<string | null>(null);
  const [newCommentText, setNewCommentText] = useState<{ [key: string]: string }>({});
  const [isCreatingTopic, setIsCreatingTopic] = useState(false);
  const [newTopicTitle, setNewTopicTitle] = useState('');
  const [newTopicContent, setNewTopicContent] = useState('');
  const [newTopicCategory, setNewTopicCategory] = useState<'Housing' | 'Food' | 'Employment' | 'Healthcare' | 'General'>('General');
  const [newTopicAuthor, setNewTopicAuthor] = useState('');
  const [forumSearch, setForumSearch] = useState('');

  const displayedJobs = showAllJobs ? jobs : jobs.slice(0, 2);

  const filteredTopics = forumTopics.filter(
    (t) =>
      t.title.toLowerCase().includes(forumSearch.toLowerCase()) ||
      t.content.toLowerCase().includes(forumSearch.toLowerCase()) ||
      t.category.toLowerCase().includes(forumSearch.toLowerCase())
  );

  const handleLikeTopic = (topicId: string) => {
    setForumTopics((prev) =>
      prev.map((t) => (t.id === topicId ? { ...t, likes: t.likes + 1 } : t))
    );
  };

  const handleAddComment = (topicId: string) => {
    const text = newCommentText[topicId]?.trim();
    if (!text) return;

    setForumTopics((prev) =>
      prev.map((topic) => {
        if (topic.id === topicId) {
          return {
            ...topic,
            repliesCount: topic.repliesCount + 1,
            comments: [
              ...topic.comments,
              {
                id: `c-${Date.now()}`,
                author: 'Community Member',
                text,
                timeAgo: 'Just now',
              },
            ],
          };
        }
        return topic;
      })
    );
    setNewCommentText((prev) => ({ ...prev, [topicId]: '' }));
  };

  const handleCreateTopicSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopicTitle.trim() || !newTopicContent.trim()) return;

    const newTopic: ForumTopic = {
      id: `topic-${Date.now()}`,
      title: newTopicTitle.trim(),
      content: newTopicContent.trim(),
      author: newTopicAuthor.trim() || 'Anonymous Neighbor',
      timeAgo: 'Just now',
      category: newTopicCategory,
      repliesCount: 0,
      likes: 1,
      comments: [],
    };

    setForumTopics([newTopic, ...forumTopics]);
    setNewTopicTitle('');
    setNewTopicContent('');
    setNewTopicAuthor('');
    setIsCreatingTopic(false);
    setExpandedTopicId(newTopic.id);
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 md:px-8 py-8 md:py-12 flex flex-col gap-14 md:gap-16">
      {/* 1. Hero Section */}
      <section className="flex flex-col md:flex-row items-center gap-10 md:gap-14 pt-4 md:pt-8">
        <div className="w-full md:w-1/2 flex flex-col gap-5">
          <h1 className="font-heading text-4xl sm:text-5xl md:text-[52px] font-bold text-[#181c20] leading-[1.15] tracking-tight">
            Find Support,<br />
            <span className="text-[#005f6a]">Build Stability.</span>
          </h1>
          <p className="font-body text-base sm:text-lg text-[#3e494a] max-w-lg leading-relaxed">
            We provide dignified access to resources, opportunities, and a supportive community. You don't have to navigate this alone.
          </p>
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={() => scrollToSection('job-opportunities-section')}
              className="bg-[#376847] text-white font-medium text-sm md:text-base px-7 py-3 rounded-full hover:bg-[#2c5339] transition-all shadow-sm hover:shadow active:scale-[0.98] flex items-center gap-2"
              id="hero-explore-jobs-btn"
            >
              <span>Explore Jobs</span>
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </button>
            <button
              onClick={() => scrollToSection('community-forum-section')}
              className="border-2 border-[#005f6a] text-[#005f6a] font-medium text-sm md:text-base px-7 py-3 rounded-full hover:bg-[#005f6a]/10 transition-colors active:scale-[0.98]"
              id="hero-join-forum-btn"
            >
              Join Forum
            </button>
          </div>
        </div>

        {/* Hero Image */}
        <div className="w-full md:w-1/2 relative h-[320px] sm:h-[380px] md:h-[420px] rounded-2xl overflow-hidden shadow-lg border border-[#bdc8cb]/30">
          <img
            src={HERO_IMAGES.getHelpHero}
            alt="Supportive community center meeting and resources consultation"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      {/* 2. Job Opportunities Section */}
      <section
        id="job-opportunities-section"
        className="flex flex-col gap-6 bg-[#f7f9ff] p-6 sm:p-8 md:p-10 rounded-2xl border border-[#e0e3e8] card-shadow"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#181c20] mb-1.5">
              Job Opportunities
            </h2>
            <p className="font-body text-sm sm:text-base text-[#3e494a]">
              Connect with local employers committed to fair hiring, dignified wages, and respectful workplaces.
            </p>
          </div>
          <button
            onClick={() => setShowAllJobs(!showAllJobs)}
            className="font-medium text-sm text-[#005f6a] hover:underline flex items-center gap-1 self-start sm:self-auto cursor-pointer"
            id="view-all-jobs-toggle"
          >
            <span>{showAllJobs ? 'Show less' : 'View all'}</span>
            <span className="material-symbols-outlined text-sm">
              {showAllJobs ? 'expand_less' : 'chevron_right'}
            </span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {displayedJobs.map((job) => (
            <div
              key={job.id}
              onClick={() => onSelectJob(job)}
              className="bg-white p-6 rounded-xl border border-[#bdc8cb]/50 card-shadow hover:shadow-md transition-all duration-200 group cursor-pointer flex flex-col justify-between"
              id={`job-card-${job.id}`}
            >
              <div>
                <div className="flex justify-between items-start gap-2 mb-3">
                  <h3 className="font-heading text-lg sm:text-xl font-semibold text-[#181c20] group-hover:text-[#005f6a] transition-colors">
                    {job.title}
                  </h3>
                  <span
                    className={`font-medium text-xs px-2.5 py-1 rounded-full whitespace-nowrap ${
                      job.type === 'Immediate'
                        ? 'bg-[#b6edc2] text-[#3b6d4b]'
                        : 'bg-[#e0e3e8] text-[#3e494a]'
                    }`}
                  >
                    {job.type}
                  </span>
                </div>
                <p className="font-body text-sm text-[#3e494a] mb-5 line-clamp-2 leading-relaxed">
                  {job.description}
                </p>
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-[#e0e3e8]">
                <span className="font-medium text-xs sm:text-sm text-[#6e797b] flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px]">location_on</span>
                  {job.location}
                </span>
                <span className="font-semibold text-xs sm:text-sm text-[#005f6a] group-hover:underline flex items-center gap-1">
                  View details <span className="material-symbols-outlined text-xs">arrow_forward</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Talk to Someone Section */}
      <section
        id="talk-to-someone-section"
        className="flex flex-col gap-6 bg-[#f7f9ff] p-6 sm:p-8 md:p-10 rounded-2xl border border-[#e0e3e8] card-shadow"
      >
        <div className="flex flex-col gap-1.5">
          <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#181c20]">
            Talk to Someone
          </h2>
          <p className="font-body text-sm sm:text-base text-[#3e494a]">
            Our team is here to listen and provide guidance. 24/7 confidential support is just a click or call away.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Helpline */}
          <div
            onClick={onOpenHelpline}
            className="bg-white p-6 sm:p-8 rounded-xl border border-[#bdc8cb]/50 card-shadow hover:shadow-md transition-all flex flex-col items-center text-center gap-4 cursor-pointer group"
            id="helpline-card"
          >
            <div className="w-14 h-14 rounded-full bg-[#b6edc2] flex items-center justify-center text-[#3b6d4b] group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-2xl">call</span>
            </div>
            <div>
              <h3 className="font-heading text-lg font-semibold text-[#181c20]">
                Call our Helpline
              </h3>
              <p className="font-body text-base font-bold text-[#005f6a] mt-1 group-hover:underline">
                1-800-555-0199
              </p>
              <p className="text-xs text-[#6e797b] mt-1">Toll-free • Available 24/7 in 14 languages</p>
            </div>
          </div>

          {/* Card 2: Live Chat */}
          <div
            onClick={onOpenLiveChat}
            className="bg-white p-6 sm:p-8 rounded-xl border border-[#bdc8cb]/50 card-shadow hover:shadow-md transition-all flex flex-col items-center text-center gap-4 cursor-pointer group"
            id="live-chat-card"
          >
            <div className="w-14 h-14 rounded-full bg-[#b6edc2] flex items-center justify-center text-[#3b6d4b] group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-2xl">chat</span>
            </div>
            <div>
              <h3 className="font-heading text-lg font-semibold text-[#181c20]">
                Live Chat
              </h3>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenLiveChat();
                }}
                className="mt-3 bg-[#376847] text-white font-medium text-xs sm:text-sm px-5 py-2 rounded-full hover:bg-[#2c5339] transition-colors shadow-sm active:scale-95 flex items-center gap-1.5 mx-auto"
                id="start-live-chat-btn"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                Start Chat
              </button>
            </div>
          </div>

          {/* Card 3: Request a Callback */}
          <div
            onClick={onOpenCallbackModal}
            className="bg-white p-6 sm:p-8 rounded-xl border border-[#bdc8cb]/50 card-shadow hover:shadow-md transition-all flex flex-col items-center text-center gap-4 cursor-pointer group"
            id="callback-card"
          >
            <div className="w-14 h-14 rounded-full bg-[#b6edc2] flex items-center justify-center text-[#3b6d4b] group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-2xl">phone_callback</span>
            </div>
            <div>
              <h3 className="font-heading text-lg font-semibold text-[#181c20]">
                Request a Callback
              </h3>
              <p className="font-body text-xs sm:text-sm text-[#3e494a] mt-1">
                We'll call you within 15 mins
              </p>
              <span className="inline-block mt-3 text-xs font-semibold text-[#005f6a] group-hover:underline">
                Book slot →
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Community Forum Section */}
      <section
        id="community-forum-section"
        className="flex flex-col gap-6 bg-[#f7f9ff] p-6 sm:p-8 md:p-10 rounded-2xl border border-[#e0e3e8] card-shadow"
      >
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#181c20] mb-1.5">
              Community Forum
            </h2>
            <p className="font-body text-sm sm:text-base text-[#3e494a]">
              Share experiences, find local tips, and exchange mutual encouragement with neighbors.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsCreatingTopic(!isCreatingTopic)}
              className="bg-[#005f6a] text-white text-xs sm:text-sm font-medium px-4 py-2 rounded-full hover:bg-[#004f57] transition-all flex items-center gap-1.5 shadow-sm"
              id="new-topic-btn"
            >
              <span className="material-symbols-outlined text-sm">edit_square</span>
              <span>{isCreatingTopic ? 'Cancel' : 'New Topic'}</span>
            </button>
          </div>
        </div>

        {/* Search Bar for Forum */}
        <div className="relative">
          <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#6e797b] text-lg">
            search
          </span>
          <input
            type="text"
            placeholder="Search discussions by topic, keyword, or category (e.g. food pantry, housing, resume)..."
            value={forumSearch}
            onChange={(e) => setForumSearch(e.target.value)}
            className="w-full bg-white border border-[#bdc8cb]/60 rounded-xl pl-10 pr-4 py-2.5 text-sm text-[#181c20] placeholder-[#6e797b] focus:outline-none focus:ring-2 focus:ring-[#005f6a] transition-all"
          />
          {forumSearch && (
            <button
              onClick={() => setForumSearch('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-[#6e797b] hover:text-[#181c20]"
            >
              Clear
            </button>
          )}
        </div>

        {/* Create Topic Form Drawer/Card */}
        {isCreatingTopic && (
          <form
            onSubmit={handleCreateTopicSubmit}
            className="bg-white p-6 rounded-xl border border-[#005f6a]/30 shadow-md space-y-4 animate-in fade-in"
          >
            <h3 className="font-heading text-lg font-bold text-[#005f6a] flex items-center gap-2">
              <span className="material-symbols-outlined text-lg">forum</span>
              Start a Community Discussion
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Your Name or Handle
                </label>
                <input
                  type="text"
                  placeholder="e.g. Maria G. or Neighborhood Volunteer"
                  value={newTopicAuthor}
                  onChange={(e) => setNewTopicAuthor(e.target.value)}
                  className="w-full border border-[#bdc8cb] rounded-lg px-3.5 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Category
                </label>
                <select
                  value={newTopicCategory}
                  onChange={(e) => setNewTopicCategory(e.target.value as any)}
                  className="w-full border border-[#bdc8cb] rounded-lg px-3.5 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                >
                  <option value="Housing">Housing Assistance</option>
                  <option value="Food">Food & Pantries</option>
                  <option value="Employment">Jobs & Career Skills</option>
                  <option value="Healthcare">Healthcare & Wellness</option>
                  <option value="General">General Mutual Aid</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1">
                Topic Title *
              </label>
              <input
                type="text"
                required
                placeholder="What is your question or update about?"
                value={newTopicTitle}
                onChange={(e) => setNewTopicTitle(e.target.value)}
                className="w-full border border-[#bdc8cb] rounded-lg px-3.5 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1">
                Details & Information *
              </label>
              <textarea
                required
                rows={3}
                placeholder="Share context, location details, or helpful guidance..."
                value={newTopicContent}
                onChange={(e) => setNewTopicContent(e.target.value)}
                className="w-full border border-[#bdc8cb] rounded-lg px-3.5 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsCreatingTopic(false)}
                className="px-4 py-2 rounded-lg border border-[#bdc8cb] text-sm text-[#3e494a] hover:bg-[#f1f4f9]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-[#005f6a] text-white text-sm font-medium hover:bg-[#004f57] shadow-sm"
              >
                Publish Topic
              </button>
            </div>
          </form>
        )}

        {/* Forum Topic Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTopics.map((topic) => {
            const isExpanded = expandedTopicId === topic.id;

            return (
              <div
                key={topic.id}
                className={`bg-white p-6 rounded-xl border border-[#bdc8cb]/50 card-shadow transition-all duration-200 flex flex-col justify-between ${
                  isExpanded ? 'ring-2 ring-[#005f6a]/40' : 'hover:shadow-md'
                }`}
                id={`forum-topic-${topic.id}`}
              >
                <div>
                  <div className="flex justify-between items-start gap-2 mb-2">
                    <span className="text-[11px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded bg-[#f1f4f9] text-[#005f6a]">
                      {topic.category}
                    </span>
                    <button
                      onClick={() => handleLikeTopic(topic.id)}
                      className="flex items-center gap-1 text-xs text-[#6e797b] hover:text-[#953914] transition-colors"
                      title="Support this post"
                    >
                      <span className="material-symbols-outlined text-[16px] text-[#953914]">
                        favorite
                      </span>
                      <span>{topic.likes}</span>
                    </button>
                  </div>

                  <h3
                    onClick={() =>
                      setExpandedTopicId(isExpanded ? null : topic.id)
                    }
                    className="font-heading text-lg font-semibold text-[#181c20] hover:text-[#005f6a] transition-colors cursor-pointer mb-2"
                  >
                    {topic.title}
                  </h3>

                  <p className="font-body text-sm text-[#3e494a] mb-4 leading-relaxed">
                    {topic.content}
                  </p>
                </div>

                <div>
                  <div className="flex justify-between items-center text-xs text-[#6e797b] pt-3 border-t border-[#e0e3e8]">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-[#181c20]">{topic.author}</span>
                      <span>•</span>
                      <span>{topic.timeAgo}</span>
                    </div>

                    <button
                      onClick={() =>
                        setExpandedTopicId(isExpanded ? null : topic.id)
                      }
                      className="text-[#005f6a] font-medium hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <span className="material-symbols-outlined text-[15px]">chat_bubble</span>
                      <span>{topic.repliesCount} {topic.repliesCount === 1 ? 'reply' : 'replies'}</span>
                    </button>
                  </div>

                  {/* Expanded Comments / Reply Section */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-[#f1f4f9] space-y-3 animate-in fade-in">
                      <h4 className="text-xs font-bold text-[#181c20] uppercase tracking-wider">
                        Community Responses ({topic.comments.length})
                      </h4>

                      {topic.comments.length === 0 ? (
                        <p className="text-xs text-[#6e797b] italic">
                          No replies yet. Be the first neighbor to share helpful insight!
                        </p>
                      ) : (
                        <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                          {topic.comments.map((comment) => (
                            <div
                              key={comment.id}
                              className="bg-[#f7f9ff] p-3 rounded-lg border border-[#e0e3e8] text-xs"
                            >
                              <div className="flex justify-between items-center text-[#6e797b] mb-1">
                                <span className="font-semibold text-[#181c20]">
                                  {comment.author}
                                </span>
                                <span className="text-[10px]">{comment.timeAgo}</span>
                              </div>
                              <p className="text-[#3e494a] leading-relaxed">{comment.text}</p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Add comment input */}
                      <div className="flex gap-2 pt-2">
                        <input
                          type="text"
                          placeholder="Write a supportive reply..."
                          value={newCommentText[topic.id] || ''}
                          onChange={(e) =>
                            setNewCommentText({
                              ...newCommentText,
                              [topic.id]: e.target.value,
                            })
                          }
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleAddComment(topic.id);
                            }
                          }}
                          className="flex-1 border border-[#bdc8cb] rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#005f6a]"
                        />
                        <button
                          onClick={() => handleAddComment(topic.id)}
                          className="bg-[#005f6a] text-white text-xs font-medium px-3.5 py-1.5 rounded-lg hover:bg-[#004f57]"
                        >
                          Send
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
