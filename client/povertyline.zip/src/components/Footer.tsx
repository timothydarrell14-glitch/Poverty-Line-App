import React from 'react';
import { ActiveTab } from '../types';

interface FooterProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenStory: () => void;
  onOpenPartner: () => void;
  onOpenContact: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  setActiveTab,
  onOpenStory,
  onOpenPartner,
  onOpenContact,
}) => {
  return (
    <footer className="bg-[#ebeef3] w-full border-t border-[#bdc8cb]/60 mt-auto pt-12 pb-10 text-[#181c20]">
      <div className="max-w-[1200px] mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Col 1: Brand */}
          <div className="md:col-span-1 space-y-3">
            <div className="font-heading text-xl font-bold text-[#005f6a] flex items-center gap-2">
              <span className="material-symbols-outlined material-symbols-fill text-[#005f6a]">
                volunteer_activism
              </span>
              Poverty Line
            </div>
            <p className="text-sm text-[#3e494a] leading-relaxed">
              © 2024 Poverty Line. All rights reserved. Providing dignity through efficiency.
            </p>
          </div>

          {/* Col 2: Organization */}
          <div>
            <h4 className="font-heading text-sm font-bold text-[#005f6a] uppercase tracking-wider mb-4">
              Organization
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={onOpenStory}
                  className="text-[#3e494a] hover:text-[#005f6a] underline underline-offset-4 decoration-1 decoration-[#bdc8cb] hover:decoration-[#005f6a] transition-all"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('get-help');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-[#3e494a] hover:text-[#005f6a] underline underline-offset-4 decoration-1 decoration-[#bdc8cb] hover:decoration-[#005f6a] transition-all"
                >
                  Job Opportunities
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenPartner}
                  className="text-[#3e494a] hover:text-[#005f6a] underline underline-offset-4 decoration-1 decoration-[#bdc8cb] hover:decoration-[#005f6a] transition-all"
                >
                  Partner With Us
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Resources */}
          <div>
            <h4 className="font-heading text-sm font-bold text-[#005f6a] uppercase tracking-wider mb-4">
              Resources
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  onClick={() => {
                    setActiveTab('get-help');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-[#3e494a] hover:text-[#005f6a] underline underline-offset-4 decoration-1 decoration-[#bdc8cb] hover:decoration-[#005f6a] transition-all"
                >
                  Community Forum
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setActiveTab('donors');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-[#3e494a] hover:text-[#005f6a] underline underline-offset-4 decoration-1 decoration-[#bdc8cb] hover:decoration-[#005f6a] transition-all"
                >
                  Donor FAQ
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenContact}
                  className="text-[#3e494a] hover:text-[#005f6a] underline underline-offset-4 decoration-1 decoration-[#bdc8cb] hover:decoration-[#005f6a] transition-all"
                >
                  Privacy Policy & Terms
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Connect */}
          <div>
            <h4 className="font-heading text-sm font-bold text-[#005f6a] uppercase tracking-wider mb-4">
              Connect
            </h4>
            <div className="flex items-center gap-3">
              <button
                onClick={onOpenContact}
                title="Send an email"
                className="w-10 h-10 rounded-full bg-[#e5e8ee] hover:bg-[#005f6a] hover:text-white text-[#3e494a] flex items-center justify-center transition-colors duration-150 shadow-sm"
              >
                <span className="material-symbols-outlined text-lg">mail</span>
              </button>
              <button
                onClick={() => {
                  if (navigator.share) {
                    navigator.share({
                      title: 'Poverty Line - Dignity Through Efficiency',
                      url: window.location.href,
                    }).catch(() => {});
                  } else {
                    navigator.clipboard.writeText(window.location.href);
                    alert('App link copied to clipboard!');
                  }
                }}
                title="Share this platform"
                className="w-10 h-10 rounded-full bg-[#e5e8ee] hover:bg-[#005f6a] hover:text-white text-[#3e494a] flex items-center justify-center transition-colors duration-150 shadow-sm"
              >
                <span className="material-symbols-outlined text-lg">share</span>
              </button>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-[#bdc8cb]/40 text-center text-xs text-[#6e797b]">
          A unified, community-powered network bringing dignity, transparency, and operational efficiency to vulnerable communities.
        </div>
      </div>
    </footer>
  );
};
