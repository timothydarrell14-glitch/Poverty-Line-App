import React from 'react';
import { Program } from '../types';
import { HERO_IMAGES, ACTIVE_PROGRAMS } from '../data/mockData';

interface DonorsScreenProps {
  onSelectProgramForDonation: (program: Program) => void;
  onOpenGeneralDonation: () => void;
  onOpenImpactReport: () => void;
}

export const DonorsScreen: React.FC<DonorsScreenProps> = ({
  onSelectProgramForDonation,
  onOpenGeneralDonation,
  onOpenImpactReport,
}) => {
  return (
    <div className="max-w-[1200px] mx-auto px-4 md:px-8 py-8 md:py-12 flex flex-col gap-14 md:gap-16">
      {/* 1. Hero Section */}
      <section className="flex flex-col md:flex-row items-center gap-10 md:gap-14 pt-4 md:pt-8">
        {/* Left column text */}
        <div className="w-full md:w-1/2 flex flex-col gap-5">
          <div className="inline-flex items-center gap-2 bg-[#ffefeb] text-[#953914] px-3.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider w-max">
            <span className="material-symbols-outlined text-sm">favorite</span>
            Empowering Resilient Futures
          </div>

          <h1 className="font-heading text-4xl sm:text-5xl md:text-[52px] font-bold text-[#181c20] leading-[1.15] tracking-tight">
            Together, We Bring Hope and <span className="text-[#953914]">Change Lives</span>
          </h1>

          <p className="font-body text-base sm:text-lg text-[#3e494a] max-w-lg leading-relaxed">
            Your generous donations empower communities, provide essential resources, and create lasting sustainable change. Join us in making a difference today.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={onOpenGeneralDonation}
              className="bg-[#953914] text-white font-medium text-sm md:text-base px-8 py-3.5 rounded-full hover:bg-[#802a05] transition-all shadow-md hover:shadow-lg active:scale-[0.98] flex items-center gap-2"
              id="donors-hero-donate-btn"
            >
              <span className="material-symbols-outlined text-sm">volunteer_activism</span>
              <span>Make a Donation</span>
            </button>
            <button
              onClick={onOpenImpactReport}
              className="border-2 border-[#953914] text-[#953914] font-medium text-sm md:text-base px-7 py-3 rounded-full hover:bg-[#953914]/10 transition-colors active:scale-[0.98] flex items-center gap-1.5"
              id="donors-download-report-btn"
            >
              <span className="material-symbols-outlined text-sm">description</span>
              <span>View Impact Report</span>
            </button>
          </div>

          {/* Quick Stats Bento Row */}
          <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#e0e3e8] mt-2">
            <div>
              <div className="font-heading text-2xl sm:text-3xl font-bold text-[#953914]">
                10K+
              </div>
              <div className="text-xs text-[#6e797b] font-medium">Donations Received</div>
            </div>
            <div>
              <div className="font-heading text-2xl sm:text-3xl font-bold text-[#005f6a]">
                50K+
              </div>
              <div className="text-xs text-[#6e797b] font-medium">Lives Impacted</div>
            </div>
            <div>
              <div className="font-heading text-2xl sm:text-3xl font-bold text-[#376847]">
                520+
              </div>
              <div className="text-xs text-[#6e797b] font-medium">Active Volunteers</div>
            </div>
          </div>
        </div>

        {/* Hero Image on right */}
        <div className="w-full md:w-1/2 relative h-[340px] sm:h-[400px] md:h-[450px] rounded-2xl overflow-hidden shadow-lg border border-[#bdc8cb]/30">
          <img
            src={HERO_IMAGES.donorsHero}
            alt="Warm community food and essentials distribution"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      {/* 2. Active Programs Bento Grid */}
      <section className="flex flex-col gap-8" id="active-programs-section">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-[#181c20]">
              Active Programs
            </h2>
            <p className="font-body text-base text-[#3e494a] mt-1 max-w-xl">
              Choose where your support creates direct, transparent, and durable impact.
            </p>
          </div>
          <button
            onClick={onOpenGeneralDonation}
            className="text-sm font-semibold text-[#953914] hover:underline flex items-center gap-1 self-start md:self-auto cursor-pointer"
          >
            <span>Custom allocation or monthly pledge</span>
            <span className="material-symbols-outlined text-sm">arrow_forward</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {ACTIVE_PROGRAMS.map((program) => {
            const isClinic = program.id === 'prog-4';

            return (
              <div
                key={program.id}
                className="bg-white rounded-2xl border border-[#bdc8cb]/50 overflow-hidden card-shadow hover:shadow-lg transition-all duration-200 flex flex-col group"
                id={`program-card-${program.id}`}
              >
                {/* Image Container with Tag Badge */}
                <div className="relative h-56 sm:h-64 w-full overflow-hidden bg-slate-100">
                  <img
                    src={program.imageUrl}
                    alt={program.imageAlt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-white/95 backdrop-blur-sm text-[#181c20] text-xs font-bold px-3 py-1.5 rounded-full shadow-sm flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-xs text-[#953914]">
                        {program.icon}
                      </span>
                      {program.category}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 sm:p-7 flex flex-col flex-grow justify-between gap-4">
                  <div>
                    <h3 className="font-heading text-xl sm:text-2xl font-bold text-[#181c20] mb-2 group-hover:text-[#953914] transition-colors">
                      {program.title}
                    </h3>
                    <p className="font-body text-sm sm:text-base text-[#3e494a] leading-relaxed">
                      {program.description}
                    </p>
                  </div>

                  {/* Impact Metric & Optional Goal Progress Bar */}
                  <div className="space-y-3 pt-2">
                    {isClinic && (
                      <div className="space-y-1.5 bg-[#f7f9ff] p-3 rounded-xl border border-[#e0e3e8]">
                        <div className="flex justify-between text-xs font-semibold text-[#181c20]">
                          <span>Campaign Goal: $1,000,000</span>
                          <span className="text-[#953914]">65% Funded ($650K)</span>
                        </div>
                        <div className="w-full h-2.5 bg-[#e0e3e8] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-[#953914] rounded-full transition-all duration-500"
                            style={{ width: '65%' }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-2 text-xs text-[#6e797b]">
                      <span className="material-symbols-outlined text-sm text-[#005f6a]">
                        verified
                      </span>
                      <span>{program.impactMetric}</span>
                    </div>

                    <div className="pt-2 flex justify-between items-center border-t border-[#e0e3e8]">
                      <button
                        onClick={() => onSelectProgramForDonation(program)}
                        className="bg-[#953914] text-white font-medium text-sm px-6 py-2.5 rounded-full hover:bg-[#802a05] active:scale-95 transition-all shadow-sm flex items-center gap-2"
                        id={`support-program-btn-${program.id}`}
                      >
                        <span>Support Program</span>
                        <span className="material-symbols-outlined text-xs">arrow_forward</span>
                      </button>

                      <button
                        onClick={() => onSelectProgramForDonation(program)}
                        className="text-xs font-semibold text-[#3e494a] hover:text-[#953914] underline underline-offset-4"
                      >
                        Learn more
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. Transparency & Direct Impact Pledge */}
      <section className="bg-[#ebeef3] p-8 md:p-12 rounded-3xl border border-[#bdc8cb]/60 flex flex-col md:flex-row items-center gap-8 justify-between">
        <div className="space-y-3 max-w-xl">
          <div className="flex items-center gap-2 text-[#005f6a] font-bold text-sm">
            <span className="material-symbols-outlined">shield</span>
            100% Transparency Commitment
          </div>
          <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#181c20]">
            Every cent tracked with open accountability.
          </h3>
          <p className="font-body text-sm sm:text-base text-[#3e494a] leading-relaxed">
            All program logistics and expenditures are audited every month. Donors receive live updates and dispatch confirmations as provisions reach local distribution hubs.
          </p>
        </div>

        <button
          onClick={onOpenGeneralDonation}
          className="bg-[#005f6a] text-white font-medium px-8 py-3.5 rounded-full hover:bg-[#004f57] shadow-sm transition-all whitespace-nowrap active:scale-95 flex items-center gap-2"
        >
          <span className="material-symbols-outlined text-sm">volunteer_activism</span>
          <span>Start Monthly Giving</span>
        </button>
      </section>
    </div>
  );
};
