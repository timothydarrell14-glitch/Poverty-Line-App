import React, { useState } from 'react';
import { LogisticsLog } from '../types';
import { HERO_IMAGES, INITIAL_LOGS, TESTIMONIALS } from '../data/mockData';

interface OrganisationsScreenProps {
  onOpenPartnerApplication: () => void;
  onOpenLiveSimulation: () => void;
}

export const OrganisationsScreen: React.FC<OrganisationsScreenProps> = ({
  onOpenPartnerApplication,
  onOpenLiveSimulation,
}) => {
  const [logs, setLogs] = useState<LogisticsLog[]>(INITIAL_LOGS);
  const [selectedTimeframe, setSelectedTimeframe] = useState<'7d' | '30d' | 'ytd'>('7d');
  const [isSimulatingDispatch, setIsSimulatingDispatch] = useState(false);

  // Distribution chart data
  const chartData = {
    '7d': [
      { day: 'Mon', height: '68%', value: '18.4K units' },
      { day: 'Tue', height: '82%', value: '22.1K units' },
      { day: 'Wed', height: '74%', value: '19.8K units' },
      { day: 'Thu', height: '94%', value: '25.6K units' },
      { day: 'Fri', height: '88%', value: '24.0K units' },
      { day: 'Sat', height: '98%', value: '26.8K units' },
      { day: 'Sun', height: '62%', value: '16.5K units' },
    ],
    '30d': [
      { day: 'Wk 1', height: '72%', value: '88.2K units' },
      { day: 'Wk 2', height: '86%', value: '104.5K units' },
      { day: 'Wk 3', height: '91%', value: '112.0K units' },
      { day: 'Wk 4', height: '95%', value: '118.4K units' },
    ],
    ytd: [
      { day: 'Q1', height: '65%', value: '310K units' },
      { day: 'Q2', height: '78%', value: '375K units' },
      { day: 'Q3', height: '90%', value: '430K units' },
      { day: 'Q4', height: '96%', value: '462K units' },
    ],
  };

  const handleSimulateNewEntry = () => {
    setIsSimulatingDispatch(true);
    setTimeout(() => {
      const newEntry: LogisticsLog = {
        id: `log-${Date.now()}`,
        title: `Dispatch #${Math.floor(405 + Math.random() * 50)} completed`,
        timestamp: 'Just now',
        type: 'delivery',
        status: 'completed',
        details: '850 nutrition packs successfully routed to East Community Shelter.',
      };
      setLogs([newEntry, ...logs]);
      setIsSimulatingDispatch(false);
    }, 600);
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 md:px-8 py-8 md:py-12 flex flex-col gap-14 md:gap-16">
      {/* 1. Hero Section */}
      <section className="flex flex-col md:flex-row items-center gap-10 md:gap-14 pt-4 md:pt-8">
        <div className="w-full md:w-1/2 flex flex-col gap-5">
          <div className="inline-flex items-center gap-2 bg-[#d5f9ff] text-[#005f6a] px-3.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider w-max">
            <span className="material-symbols-outlined text-sm">hub</span>
            Institutional Logistics Network
          </div>

          <h1 className="font-heading text-4xl sm:text-5xl md:text-[52px] font-bold text-[#181c20] leading-[1.15] tracking-tight">
            Amplify Your Impact.<br />
            <span className="text-[#005f6a]">Streamline Operations.</span>
          </h1>

          <p className="font-body text-base sm:text-lg text-[#3e494a] max-w-lg leading-relaxed">
            Connect your non-profit, NGO, or community initiative with our open logistics infrastructure. Coordinate resources, volunteers, and distribution in real-time.
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              onClick={onOpenPartnerApplication}
              className="bg-[#005f6a] text-white font-medium text-sm md:text-base px-8 py-3.5 rounded-full hover:bg-[#004f57] transition-all shadow-md hover:shadow-lg active:scale-[0.98] flex items-center gap-2"
              id="org-hero-partner-btn"
            >
              <span>Become a Partner</span>
              <span className="material-symbols-outlined text-sm">arrow_forward</span>
            </button>
            <button
              onClick={() => {
                const el = document.getElementById('command-center-preview');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="border-2 border-[#005f6a] text-[#005f6a] font-medium text-sm md:text-base px-7 py-3 rounded-full hover:bg-[#005f6a]/10 transition-colors active:scale-[0.98]"
              id="org-hero-preview-btn"
            >
              View Dashboard Preview
            </button>
          </div>
        </div>

        {/* Hero Image */}
        <div className="w-full md:w-1/2 relative h-[340px] sm:h-[400px] md:h-[450px] rounded-2xl overflow-hidden shadow-lg border border-[#bdc8cb]/30">
          <img
            src={HERO_IMAGES.organisationsHero}
            alt="Nonprofit director coordinating distribution and routes on tablet"
            className="w-full h-full object-cover"
          />
        </div>
      </section>

      {/* 2. Partner Onboarding Process */}
      <section className="flex flex-col gap-8 bg-white p-6 sm:p-8 md:p-10 rounded-2xl border border-[#e0e3e8] card-shadow">
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#181c20] mb-2">
            How We Partner
          </h2>
          <p className="font-body text-sm sm:text-base text-[#3e494a]">
            Our simple three-step integration allows organizations of any size to onboard quickly without disrupting existing ground operations.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4">
          {/* Step 1 */}
          <div className="bg-[#f7f9ff] p-6 rounded-xl border border-[#bdc8cb]/40 flex flex-col gap-3">
            <div className="w-10 h-10 rounded-full bg-[#005f6a] text-white flex items-center justify-center font-bold text-sm">
              1
            </div>
            <h3 className="font-heading text-lg font-bold text-[#181c20]">
              Application & Verification
            </h3>
            <p className="font-body text-sm text-[#3e494a] leading-relaxed">
              Submit your organization's mission, service area, and non-profit credentials for our streamlined 48-hour verification.
            </p>
          </div>

          {/* Step 2 */}
          <div className="bg-[#f7f9ff] p-6 rounded-xl border border-[#bdc8cb]/40 flex flex-col gap-3">
            <div className="w-10 h-10 rounded-full bg-[#005f6a] text-white flex items-center justify-center font-bold text-sm">
              2
            </div>
            <h3 className="font-heading text-lg font-bold text-[#181c20]">
              System Integration
            </h3>
            <p className="font-body text-sm text-[#3e494a] leading-relaxed">
              Connect your existing supply inventories, warehouse hubs, and volunteer rosters into our centralized dashboard.
            </p>
          </div>

          {/* Step 3 */}
          <div className="bg-[#f7f9ff] p-6 rounded-xl border border-[#bdc8cb]/40 flex flex-col gap-3">
            <div className="w-10 h-10 rounded-full bg-[#005f6a] text-white flex items-center justify-center font-bold text-sm">
              3
            </div>
            <h3 className="font-heading text-lg font-bold text-[#181c20]">
              Impact Tracking & Delivery
            </h3>
            <p className="font-body text-sm text-[#3e494a] leading-relaxed">
              Deploy optimized delivery routes, receive donor support transparently, and track verified impact in real-time.
            </p>
          </div>
        </div>
      </section>

      {/* 3. Partner Command Center (Bento Grid Dashboard Preview) */}
      <section id="command-center-preview" className="flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#005f6a] uppercase tracking-wider mb-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              Live Operational Telemetry
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#181c20]">
              Partner Command Center
            </h2>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handleSimulateNewEntry}
              disabled={isSimulatingDispatch}
              className="bg-white border border-[#bdc8cb] hover:bg-[#f1f4f9] text-[#181c20] text-xs font-semibold px-4 py-2 rounded-lg transition-all flex items-center gap-1.5 shadow-sm"
              id="simulate-dispatch-btn"
            >
              <span className="material-symbols-outlined text-sm">bolt</span>
              <span>{isSimulatingDispatch ? 'Simulating...' : 'Simulate Live Dispatch'}</span>
            </button>
            <button
              onClick={onOpenLiveSimulation}
              className="bg-[#005f6a] text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-[#004f57] transition-all flex items-center gap-1.5 shadow-sm"
            >
              <span>Explore Full System</span>
              <span className="material-symbols-outlined text-sm">open_in_new</span>
            </button>
          </div>
        </div>

        {/* Bento Dashboard Container */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Stat 1: Total Resources Distributed */}
          <div className="bg-white p-6 rounded-2xl border border-[#e0e3e8] card-shadow flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-semibold text-[#6e797b] uppercase tracking-wider">
                  Total Resources Distributed (YTD)
                </p>
                <h3 className="font-heading text-3xl sm:text-4xl font-bold text-[#181c20] mt-2">
                  142,500 <span className="text-sm font-normal text-[#6e797b]">units</span>
                </h3>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[#d5f9ff] text-[#005f6a] flex items-center justify-center">
                <span className="material-symbols-outlined text-xl">inventory_2</span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-[#f1f4f9] flex items-center gap-1.5 text-xs text-[#376847] font-semibold">
              <span className="material-symbols-outlined text-sm">trending_up</span>
              <span>+12% compared to last quarter</span>
            </div>
          </div>

          {/* Stat 2: Active Volunteers */}
          <div className="bg-white p-6 rounded-2xl border border-[#e0e3e8] card-shadow flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-semibold text-[#6e797b] uppercase tracking-wider">
                  Active Volunteers
                </p>
                <h3 className="font-heading text-3xl sm:text-4xl font-bold text-[#181c20] mt-2">
                  342 <span className="text-sm font-normal text-[#6e797b]">on duty</span>
                </h3>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[#b6edc2] text-[#376847] flex items-center justify-center">
                <span className="material-symbols-outlined text-xl">group</span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-[#f1f4f9] flex items-center justify-between text-xs text-[#6e797b]">
              <span>Capacity utilization: 86%</span>
              <span className="text-[#005f6a] font-semibold">24 teams deployed</span>
            </div>
          </div>

          {/* Stat 3: Pending Requests */}
          <div className="bg-white p-6 rounded-2xl border border-[#e0e3e8] card-shadow flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs font-semibold text-[#6e797b] uppercase tracking-wider">
                  Pending Requests
                </p>
                <h3 className="font-heading text-3xl sm:text-4xl font-bold text-[#953914] mt-2">
                  48 <span className="text-sm font-normal text-[#6e797b]">queues</span>
                </h3>
              </div>
              <div className="w-10 h-10 rounded-xl bg-[#ffefeb] text-[#953914] flex items-center justify-center">
                <span className="material-symbols-outlined text-xl">schedule</span>
              </div>
            </div>
            <div className="mt-4 pt-3 border-t border-[#f1f4f9] flex items-center gap-1.5 text-xs text-[#953914] font-semibold">
              <span className="material-symbols-outlined text-sm">priority_high</span>
              <span>All requests triaged under 4 hours</span>
            </div>
          </div>

          {/* Left Column in 2nd row: Distribution Efficiency Visualizer */}
          <div className="md:col-span-2 bg-white p-6 sm:p-7 rounded-2xl border border-[#e0e3e8] card-shadow flex flex-col justify-between">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
              <div>
                <h3 className="font-heading text-lg font-bold text-[#181c20]">
                  Distribution Efficiency
                </h3>
                <p className="text-xs text-[#6e797b]">Weekly throughput across regional distribution centers</p>
              </div>

              {/* Timeframe selector */}
              <div className="flex bg-[#f1f4f9] p-1 rounded-lg self-start">
                {(['7d', '30d', 'ytd'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setSelectedTimeframe(tf)}
                    className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                      selectedTimeframe === tf
                        ? 'bg-white text-[#005f6a] shadow-sm'
                        : 'text-[#6e797b] hover:text-[#181c20]'
                    }`}
                  >
                    {tf === '7d' ? '7 Days' : tf === '30d' ? '30 Days' : 'YTD'}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Bar Visualization */}
            <div className="h-44 w-full flex items-end justify-between gap-3 pt-6 pb-2 px-2 border-b border-[#e0e3e8]">
              {chartData[selectedTimeframe].map((item, idx) => (
                <div
                  key={idx}
                  className="flex-1 flex flex-col items-center gap-2 h-full justify-end group cursor-pointer"
                >
                  <div className="text-[10px] font-bold text-[#005f6a] opacity-0 group-hover:opacity-100 transition-opacity">
                    {item.value}
                  </div>
                  <div className="w-full max-w-[36px] bg-[#e0e3e8] group-hover:bg-[#007a87] rounded-t-md transition-all duration-300 relative"
                    style={{ height: item.height }}
                  >
                    <div className="absolute inset-0 bg-[#005f6a] rounded-t-md opacity-80 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <span className="text-xs font-medium text-[#6e797b] group-hover:text-[#181c20]">
                    {item.day}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-4 flex items-center justify-between text-xs text-[#6e797b]">
              <span>Average Delivery Route Time: <strong>42 minutes</strong></span>
              <span className="text-[#376847] font-semibold">98.4% On-Time Delivery Rate</span>
            </div>
          </div>

          {/* Right Column in 2nd row: Recent Logistics Log */}
          <div className="bg-white p-6 rounded-2xl border border-[#e0e3e8] card-shadow flex flex-col justify-between">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-heading text-lg font-bold text-[#181c20]">
                Recent Logistics Log
              </h3>
              <span className="text-xs text-[#005f6a] font-semibold">Live Feed</span>
            </div>

            <div className="space-y-3 flex-grow max-h-[220px] overflow-y-auto pr-1">
              {logs.map((log) => {
                let badgeColor = 'bg-[#d5f9ff] text-[#005f6a]';
                let icon = 'local_shipping';

                if (log.status === 'warning') {
                  badgeColor = 'bg-[#ffefeb] text-[#953914]';
                  icon = 'warning';
                } else if (log.status === 'info') {
                  badgeColor = 'bg-[#b6edc2] text-[#376847]';
                  icon = 'person_add';
                } else if (log.type === 'route') {
                  badgeColor = 'bg-[#e5e8ee] text-[#181c20]';
                  icon = 'alt_route';
                }

                return (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl bg-[#f7f9ff] border border-[#e0e3e8] text-xs flex flex-col gap-1 transition-all hover:bg-white"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-[#181c20] flex items-center gap-1.5">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] ${badgeColor}`}>
                          <span className="material-symbols-outlined text-[13px]">{icon}</span>
                        </span>
                        {log.title}
                      </span>
                      <span className="text-[10px] text-[#6e797b]">{log.timestamp}</span>
                    </div>
                    {log.details && (
                      <p className="text-[#3e494a] text-[11px] pl-6.5 leading-snug">
                        {log.details}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>

            <button
              onClick={onOpenPartnerApplication}
              className="mt-4 w-full text-center text-xs font-semibold text-[#005f6a] hover:underline pt-2 border-t border-[#f1f4f9]"
            >
              Connect your warehouse API →
            </button>
          </div>
        </div>
      </section>

      {/* 4. Trusted by Leading Organizations & Testimonials */}
      <section className="flex flex-col gap-8 bg-[#ebeef3] p-8 sm:p-10 rounded-3xl border border-[#bdc8cb]/60">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-xs font-bold text-[#005f6a] uppercase tracking-widest mb-1">
            Proven Field Collaboration
          </p>
          <h2 className="font-heading text-2xl sm:text-3xl font-bold text-[#181c20]">
            Trusted by Leading Organizations
          </h2>
        </div>

        {/* Partner Logos Bar */}
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-14 opacity-70 grayscale hover:grayscale-0 transition-all">
          <div className="font-heading text-lg sm:text-xl font-extrabold tracking-tighter text-[#3e494a] flex items-center gap-1">
            <span className="material-symbols-outlined">public</span> GlobalCare
          </div>
          <div className="font-heading text-lg sm:text-xl font-extrabold tracking-tighter text-[#3e494a] flex items-center gap-1">
            <span className="material-symbols-outlined">medical_information</span> HealthNet
          </div>
          <div className="font-heading text-lg sm:text-xl font-extrabold tracking-tighter text-[#3e494a] flex items-center gap-1">
            <span className="material-symbols-outlined">eco</span> FoodForward
          </div>
          <div className="font-heading text-lg sm:text-xl font-extrabold tracking-tighter text-[#3e494a] flex items-center gap-1">
            <span className="material-symbols-outlined">cottage</span> ShelterOrg
          </div>
        </div>

        {/* Testimonials Bento Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="bg-white p-6 sm:p-7 rounded-2xl border border-[#bdc8cb]/40 card-shadow flex flex-col justify-between gap-5"
            >
              <div className="space-y-3">
                <span className="material-symbols-outlined text-3xl text-[#005f6a]/40 material-symbols-fill">
                  format_quote
                </span>
                <p className="font-body text-sm sm:text-base text-[#181c20] italic leading-relaxed">
                  "{t.quote}"
                </p>
              </div>

              <div className="flex items-center gap-3.5 pt-4 border-t border-[#e0e3e8]">
                <img
                  src={t.avatarUrl}
                  alt={t.avatarAlt}
                  className="w-12 h-12 rounded-full object-cover border border-[#bdc8cb]"
                />
                <div>
                  <h4 className="font-heading text-sm font-bold text-[#181c20]">
                    {t.author}
                  </h4>
                  <p className="text-xs text-[#6e797b]">
                    {t.role}, <strong className="text-[#005f6a]">{t.organization}</strong>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
