import React, { useState, useEffect } from 'react';
import { ActiveTab } from '../types';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenDonate: () => void;
  onOpenLogin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenDonate,
  onOpenLogin,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 12) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { id: ActiveTab; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'get-help', label: 'Get Help' },
    { id: 'donors', label: 'Donors' },
    { id: 'organisations', label: 'Organisations' },
    { id: 'contact', label: 'Contact Us' },
  ];

  const handleNavClick = (tab: ActiveTab) => {
    setActiveTab(tab);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <nav
        id="navbar"
        className={`fixed top-0 left-0 right-0 w-full z-50 bg-white/95 backdrop-blur-md border-b border-[#bdc8cb]/40 transition-all duration-300 ${
          isScrolled ? 'shadow-md py-3' : 'shadow-sm py-4'
        }`}
      >
        <div className="max-w-[1200px] mx-auto px-4 md:px-8 flex items-center justify-between h-[56px]">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 text-[#005f6a] font-bold text-2xl tracking-tight transition-transform hover:opacity-95 text-left focus:outline-none"
            id="brand-logo"
          >
            <span className="material-symbols-outlined material-symbols-fill text-[#005f6a] text-3xl">
              volunteer_activism
            </span>
            <span className="font-heading font-bold text-[22px] md:text-[24px]">Poverty Line</span>
          </button>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-7 text-[15px] font-medium text-[#3e494a]">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative py-1.5 transition-colors duration-150 focus:outline-none ${
                    isActive
                      ? 'text-[#005f6a] font-semibold'
                      : 'hover:text-[#005f6a]'
                  }`}
                  id={`nav-link-${item.id}`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-[#005f6a] rounded-full" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Actions: Login & Donate Now */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={onOpenLogin}
              className="text-[#005f6a] hover:bg-[#f1f4f9] px-4 py-2 rounded-full font-medium text-sm transition-colors duration-150 focus:outline-none"
              id="login-btn-header"
            >
              Login
            </button>
            <button
              onClick={onOpenDonate}
              className="bg-[#005f6a] text-white px-5 py-2.5 rounded-full font-medium text-sm hover:bg-[#004f57] active:scale-[0.98] transition-all shadow-sm hover:shadow duration-150 flex items-center gap-1.5"
              id="donate-btn-header"
            >
              <span className="material-symbols-outlined text-sm">favorite</span>
              Donate Now
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden text-[#181c20] p-2 rounded-lg hover:bg-black/5 focus:outline-none"
            aria-label="Toggle navigation menu"
            id="mobile-menu-btn"
          >
            <span className="material-symbols-outlined text-2xl">
              {isMobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 top-[72px] bg-white z-40 md:hidden flex flex-col p-6 overflow-y-auto animate-in fade-in duration-200"
          id="mobile-menu-drawer"
        >
          <div className="flex flex-col space-y-4 pt-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`text-left text-xl py-3 border-b border-[#e0e3e8] font-heading ${
                  activeTab === item.id
                    ? 'text-[#005f6a] font-bold pl-2 border-l-4 border-l-[#005f6a]'
                    : 'text-[#181c20] hover:text-[#005f6a]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="mt-8 pt-4 flex flex-col gap-3">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenDonate();
              }}
              className="w-full bg-[#005f6a] text-white py-3.5 rounded-full font-medium shadow-sm hover:bg-[#004f57]"
            >
              Donate Now
            </button>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenLogin();
              }}
              className="w-full border-2 border-[#005f6a] text-[#005f6a] py-3.5 rounded-full font-medium hover:bg-[#f1f4f9]"
            >
              Login
            </button>
          </div>
        </div>
      )}
    </>
  );
};
