import React from 'react';
import { ActiveTab } from '../types';
import { HERO_IMAGES } from '../data/mockData';

interface HomeScreenProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenDonate: () => void;
  onOpenStory: () => void;
  onOpenMethodology: () => void;
  onOpenPartner: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  setActiveTab,
  onOpenDonate,
  onOpenStory,
  onOpenMethodology,
  onOpenPartner,
}) => {
  return (
    <div className="flex flex-col w-full">
      {/* 1. Hero Section */}
      <section className="relative w-full min-h-[82vh] flex items-center justify-center overflow-hidden pt-12 pb-20">
        {/* Background Image with warm gradient overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={HERO_IMAGES.homeHeroBg}
            alt="Dignified community support and human connection"
            className="w-full h-full object-cover object-center opacity-90 scale-100"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#f7f9ff] via-[#f7f9ff]/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-[#f7f9ff]" />
        </div>

        {/* Hero Card / Glass Container */}
        <div className="relative z-10 w-full max-w-[1200px] mx-auto px-4 md:px-8 text-center mt-12 md:mt-20">
          <div className="glass-panel inline-block px-6 py-10 sm:px-10 sm:py-14 md:px-16 md:py-16 rounded-2xl md:rounded-3xl shadow-xl max-w-3xl mx-auto border border-white/70">
            <h1 className="font-heading text-3xl sm:text-4xl md:text-5xl lg:text-[54px] font-bold text-[#181c20] mb-5 tracking-tight leading-[1.15]">
              Dignity Through <span className="text-[#005f6a]">Efficiency</span>
            </h1>
            <p className="font-body text-base sm:text-lg text-[#3e494a] mb-9 max-w-2xl mx-auto leading-relaxed">
              We bridge the gap between resources and those who need them most. A streamlined, community-built approach to strengthening access to clean water, education, and sustainable livelihoods.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => {
                  setActiveTab('donors');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="w-full sm:w-auto bg-[#005f6a] text-white font-medium text-sm md:text-base px-8 py-3.5 rounded-full hover:bg-[#004f57] transition-all shadow-md hover:shadow-lg active:scale-[0.98] duration-150 flex items-center justify-center gap-2"
                id="hero-discover-impact-btn"
              >
                <span>Discover Our Impact</span>
                <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </button>
              <button
                onClick={onOpenStory}
                className="w-full sm:w-auto border-2 border-[#005f6a] text-[#005f6a] font-medium text-sm md:text-base px-8 py-3.5 rounded-full hover:bg-[#005f6a]/10 transition-colors active:scale-[0.98] duration-150"
                id="hero-read-story-btn"
              >
                Read Our Story
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Focus Areas / Bento Grid: Our Collaborative Ecosystem */}
      <section className="py-16 md:py-24 bg-[#f7f9ff]" id="focus-areas">
        <div className="max-w-[1200px] mx-auto px-4 md:px-8">
          <div className="text-center mb-14 md:mb-16">
            <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#181c20] mb-3">
              Our Collaborative Ecosystem
            </h2>
            <p className="font-body text-base sm:text-lg text-[#3e494a] max-w-2xl mx-auto">
              A unified platform connecting individuals in need, dedicated donors, and partner organizations to create lasting change.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            {/* Card 1: Get Help (Sage Green) */}
            <div
              onClick={() => {
                setActiveTab('get-help');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-white rounded-2xl p-7 md:p-8 border border-[#e0e3e8] card-shadow card-hover flex flex-col group relative overflow-hidden cursor-pointer"
              id="get-help-bento-card"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#376847] opacity-5 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-110" />
              <div className="w-14 h-14 rounded-full bg-[#b6edc2] text-[#3b6d4b] flex items-center justify-center mb-6 shadow-sm">
                <span className="material-symbols-outlined text-2xl">handshake</span>
              </div>
              <h3 className="font-heading text-xl md:text-2xl font-bold text-[#181c20] mb-3 relative z-10">
                Get Help
              </h3>
              <p className="font-body text-sm md:text-base text-[#3e494a] mb-8 flex-grow relative z-10 leading-relaxed">
                Access streamlined resources for daily necessities, educational support, and community assistance programs designed for immediate impact and long-term stability.
              </p>
              <div className="inline-flex items-center gap-2 text-[#376847] font-semibold text-sm hover:underline decoration-2 underline-offset-4 relative z-10 mt-auto w-max">
                Learn More <span className="material-symbols-outlined text-sm">arrow_forward</span>
              </div>
            </div>

            {/* Card 2: Donors (Terracotta) */}
            <div
              onClick={() => {
                setActiveTab('donors');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-white rounded-2xl p-7 md:p-8 border border-[#e0e3e8] card-shadow card-hover flex flex-col group relative overflow-hidden cursor-pointer"
              id="donors-bento-card"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#953914] opacity-5 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-110" />
              <div className="w-14 h-14 rounded-full bg-[#b5502a] text-[#ffefeb] flex items-center justify-center mb-6 shadow-sm">
                <span className="material-symbols-outlined text-2xl">favorite</span>
              </div>
              <h3 className="font-heading text-xl md:text-2xl font-bold text-[#181c20] mb-3 relative z-10">
                Donors
              </h3>
              <p className="font-body text-sm md:text-base text-[#3e494a] mb-8 flex-grow relative z-10 leading-relaxed">
                See exactly how your contributions build sustainable futures. We prioritize transparency, ensuring every resource is efficiently allocated to maximize community benefit.
              </p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenDonate();
                }}
                className="bg-[#953914] text-white font-medium text-sm px-6 py-2.5 rounded-full hover:bg-[#802a05] transition-colors shadow-sm mt-auto w-max self-start active:scale-95 flex items-center gap-1.5"
              >
                <span>Support Now</span>
                <span className="material-symbols-outlined text-xs">arrow_forward</span>
              </button>
            </div>

            {/* Card 3: Organisations (Primary Teal/Slate) */}
            <div
              onClick={() => {
                setActiveTab('organisations');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="bg-white rounded-2xl p-7 md:p-8 border border-[#e0e3e8] card-shadow card-hover flex flex-col group relative overflow-hidden cursor-pointer"
              id="organisations-bento-card"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#005f6a] opacity-5 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-110" />
              <div className="w-14 h-14 rounded-full bg-[#007a87] text-[#d5f9ff] flex items-center justify-center mb-6 shadow-sm">
                <span className="material-symbols-outlined text-2xl">domain</span>
              </div>
              <h3 className="font-heading text-xl md:text-2xl font-bold text-[#181c20] mb-3 relative z-10">
                Organisations
              </h3>
              <p className="font-body text-sm md:text-base text-[#3e494a] mb-8 flex-grow relative z-10 leading-relaxed">
                Join our network of institutional partners. By aligning our operational capacities, we can scale proven solutions and deliver comprehensive support across regions.
              </p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenPartner();
                }}
                className="border-2 border-[#005f6a] text-[#005f6a] font-medium text-sm px-6 py-2.5 rounded-full hover:bg-[#005f6a]/10 transition-colors mt-auto w-max self-start active:scale-95"
              >
                Partner With Us
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Image & Text Feature Section: A system shaped by sustainable progress */}
      <section className="py-16 md:py-24 bg-[#f1f4f9]">
        <div className="max-w-[1200px] mx-auto px-4 md:px-8">
          <div className="flex flex-col md:flex-row gap-10 md:gap-14 items-center">
            {/* Image on left */}
            <div className="w-full md:w-1/2 order-2 md:order-1 relative rounded-2xl overflow-hidden shadow-lg border border-[#bdc8cb]/30">
              <img
                src={HERO_IMAGES.sustainableProgress}
                alt="Community members collaborating around a large table in an open modern center"
                className="w-full h-[360px] sm:h-[420px] object-cover"
              />
            </div>

            {/* Text on right */}
            <div className="w-full md:w-1/2 order-1 md:order-2">
              <h2 className="font-heading text-2xl sm:text-3xl md:text-4xl font-bold text-[#181c20] mb-5 leading-tight">
                A system shaped by sustainable progress
              </h2>
              <p className="font-body text-base sm:text-lg text-[#3e494a] mb-6 leading-relaxed">
                Poverty Line builds programs that adapt to real life. We respect the culture and pace of each community we partner with. Every component is designed to fit, grow, and evolve without disrupting the people it serves.
              </p>

              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <span className="material-symbols-outlined text-[#005f6a] mt-0.5 text-2xl material-symbols-fill">
                    check_circle
                  </span>
                  <div>
                    <h4 className="font-heading text-base font-semibold text-[#181c20]">
                      Adaptive Programs
                    </h4>
                    <p className="font-body text-sm text-[#3e494a]">
                      Systems that scale over time with community needs and local feedback.
                    </p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <span className="material-symbols-outlined text-[#005f6a] mt-0.5 text-2xl material-symbols-fill">
                    check_circle
                  </span>
                  <div>
                    <h4 className="font-heading text-base font-semibold text-[#181c20]">
                      Transparent Operations
                    </h4>
                    <p className="font-body text-sm text-[#3e494a]">
                      Clear visibility into resource allocation, verified delivery logs, and impact metrics.
                    </p>
                  </div>
                </li>
              </ul>

              <button
                onClick={onOpenMethodology}
                className="text-[#005f6a] font-semibold text-sm sm:text-base underline decoration-2 underline-offset-4 hover:text-[#004f57] transition-colors flex items-center gap-1.5"
                id="explore-methodology-btn"
              >
                <span>Explore our methodology</span>
                <span className="material-symbols-outlined text-sm">arrow_outward</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
