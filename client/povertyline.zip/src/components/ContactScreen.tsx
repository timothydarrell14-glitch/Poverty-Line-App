import React, { useState } from 'react';

export const ContactScreen: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
      alert('Thank you for contacting Poverty Line. Our community liaison will respond within 24 hours.');
    }, 1000);
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 md:px-8 py-10 md:py-16">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <h1 className="font-heading text-3xl sm:text-4xl md:text-5xl font-bold text-[#181c20] mb-3">
          Get in Touch
        </h1>
        <p className="font-body text-base sm:text-lg text-[#3e494a]">
          Whether you have questions about programs, want to volunteer, or need emergency assistance coordination, we're here.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Contact Info Cards */}
        <div className="space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-[#e0e3e8] card-shadow">
            <div className="w-10 h-10 rounded-full bg-[#d5f9ff] text-[#005f6a] flex items-center justify-center mb-3">
              <span className="material-symbols-outlined">call</span>
            </div>
            <h3 className="font-heading text-base font-bold text-[#181c20]">24/7 Helpline</h3>
            <p className="text-xs text-[#6e797b] mt-1">Toll-free across North America</p>
            <p className="text-sm font-bold text-[#005f6a] mt-2">1-800-555-0199</p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#e0e3e8] card-shadow">
            <div className="w-10 h-10 rounded-full bg-[#ffefeb] text-[#953914] flex items-center justify-center mb-3">
              <span className="material-symbols-outlined">mail</span>
            </div>
            <h3 className="font-heading text-base font-bold text-[#181c20]">Direct Email</h3>
            <p className="text-xs text-[#6e797b] mt-1">For general & donor inquiries</p>
            <p className="text-sm font-bold text-[#953914] mt-2">support@povertyline.org</p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-[#e0e3e8] card-shadow">
            <div className="w-10 h-10 rounded-full bg-[#b6edc2] text-[#376847] flex items-center justify-center mb-3">
              <span className="material-symbols-outlined">location_on</span>
            </div>
            <h3 className="font-heading text-base font-bold text-[#181c20]">Central Coordination</h3>
            <p className="text-xs text-[#6e797b] mt-1">Main Distribution Hub</p>
            <p className="text-sm font-medium text-[#181c20] mt-2">
              450 Community Way, Suite 100<br />
              Central District, CA 94103
            </p>
          </div>
        </div>

        {/* Contact Form */}
        <div className="md:col-span-2 bg-white p-8 rounded-2xl border border-[#e0e3e8] card-shadow">
          <h2 className="font-heading text-2xl font-bold text-[#181c20] mb-6">
            Send a Direct Message
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Your Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Maya Lin"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-[#bdc8cb] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  required
                  placeholder="maya@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-[#bdc8cb] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1">
                Subject
              </label>
              <input
                type="text"
                placeholder="How can we help you?"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-[#bdc8cb] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1">
                Message *
              </label>
              <textarea
                required
                rows={4}
                placeholder="Write your message here..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3.5 py-2.5 border border-[#bdc8cb] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              />
            </div>

            <button
              type="submit"
              disabled={submitted}
              className="bg-[#005f6a] text-white font-semibold text-sm px-8 py-3.5 rounded-full hover:bg-[#004f57] shadow-sm transition-all active:scale-[0.98]"
            >
              {submitted ? 'Sending Message...' : 'Send Message'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
