import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Program, Job } from '../types';
import { ACTIVE_PROGRAMS } from '../data/mockData';

// -------------------- 1. DONATION MODAL --------------------
interface DonationModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedProgram?: Program | null;
}

export const DonationModal: React.FC<DonationModalProps> = ({
  isOpen,
  onClose,
  selectedProgram,
}) => {
  const [selectedProgId, setSelectedProgId] = useState<string>(
    selectedProgram?.id || 'general'
  );
  const [amount, setAmount] = useState<number>(50);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [frequency, setFrequency] = useState<'one-time' | 'monthly'>('one-time');
  const [donorName, setDonorName] = useState<string>('');
  const [donorEmail, setDonorEmail] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'gpay' | 'bank'>('card');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [receiptNumber, setReceiptNumber] = useState<string>('');

  if (!isOpen) return null;

  const presetAmounts = [25, 50, 100, 250];

  const handleDonate = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAmount = customAmount ? parseFloat(customAmount) : amount;
    if (!finalAmount || finalAmount <= 0) return;

    // Trigger celebratory confetti
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#005f6a', '#376847', '#953914', '#fbc02d'],
    });

    setReceiptNumber(`PL-${Math.floor(100000 + Math.random() * 900000)}`);
    setIsSuccess(true);
  };

  const handleReset = () => {
    setIsSuccess(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-[#bdc8cb]/50 overflow-hidden my-8">
        {/* Header */}
        <div className="bg-[#f7f9ff] px-6 py-4 border-b border-[#e0e3e8] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#953914] text-2xl material-symbols-fill">
              favorite
            </span>
            <div>
              <h3 className="font-heading text-lg font-bold text-[#181c20]">
                {isSuccess ? 'Thank You for Your Generosity' : 'Make a Dignified Contribution'}
              </h3>
              <p className="text-xs text-[#6e797b]">Tax-exempt 501(c)(3) certified organization</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#6e797b] hover:text-[#181c20] p-1 rounded-lg hover:bg-black/5"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Content */}
        {isSuccess ? (
          <div className="p-6 sm:p-8 space-y-6 text-center">
            <div className="w-16 h-16 bg-[#b6edc2] text-[#376847] rounded-full flex items-center justify-center mx-auto shadow-sm">
              <span className="material-symbols-outlined text-3xl">check_circle</span>
            </div>

            <div className="space-y-2">
              <h4 className="font-heading text-2xl font-bold text-[#181c20]">
                Donation Received with Gratitude!
              </h4>
              <p className="text-sm text-[#3e494a] max-w-md mx-auto leading-relaxed">
                Your gift of <strong>${customAmount ? customAmount : amount} ({frequency})</strong> will be directly routed to supply chains within 48 hours.
              </p>
            </div>

            {/* Receipt Summary Box */}
            <div className="bg-[#f7f9ff] p-5 rounded-xl border border-[#e0e3e8] text-left text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-[#6e797b]">Receipt Reference:</span>
                <span className="font-mono font-bold text-[#181c20]">{receiptNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6e797b]">Allocated Program:</span>
                <span className="font-semibold text-[#005f6a]">
                  {selectedProgId === 'general'
                    ? 'General Community Fund'
                    : ACTIVE_PROGRAMS.find((p) => p.id === selectedProgId)?.title || 'Program Fund'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6e797b]">Donor Name:</span>
                <span className="font-medium text-[#181c20]">{donorName || 'Anonymous Supporter'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6e797b]">Tax Status:</span>
                <span className="text-[#376847] font-semibold">100% Tax-Deductible</span>
              </div>
            </div>

            <div className="flex justify-center gap-3">
              <button
                onClick={() => {
                  alert(`Receipt ${receiptNumber} printed & sent to ${donorEmail || 'your email'}.`);
                }}
                className="px-5 py-2.5 rounded-full border border-[#bdc8cb] text-xs font-semibold text-[#181c20] hover:bg-[#f1f4f9] flex items-center gap-1.5"
              >
                <span className="material-symbols-outlined text-sm">print</span>
                Download Receipt
              </button>
              <button
                onClick={handleReset}
                className="px-6 py-2.5 rounded-full bg-[#005f6a] text-white text-xs font-semibold hover:bg-[#004f57] shadow-sm"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleDonate} className="p-6 space-y-5">
            {/* Frequency Toggle */}
            <div className="flex bg-[#f1f4f9] p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setFrequency('one-time')}
                className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                  frequency === 'one-time'
                    ? 'bg-white text-[#005f6a] shadow-sm'
                    : 'text-[#6e797b] hover:text-[#181c20]'
                }`}
              >
                One-Time Gift
              </button>
              <button
                type="button"
                onClick={() => setFrequency('monthly')}
                className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1 ${
                  frequency === 'monthly'
                    ? 'bg-white text-[#953914] shadow-sm'
                    : 'text-[#6e797b] hover:text-[#181c20]'
                }`}
              >
                <span className="material-symbols-outlined text-xs">autorenew</span>
                Monthly Pledge (Best Impact)
              </button>
            </div>

            {/* Program Selection */}
            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1.5">
                Select Initiative
              </label>
              <select
                value={selectedProgId}
                onChange={(e) => setSelectedProgId(e.target.value)}
                className="w-full border border-[#bdc8cb] rounded-xl px-3.5 py-2.5 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              >
                <option value="general">✨ General Community Fund (Where Most Needed)</option>
                {ACTIVE_PROGRAMS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} ({p.category})
                  </option>
                ))}
              </select>
            </div>

            {/* Amount Selection */}
            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1.5">
                Contribution Amount
              </label>
              <div className="grid grid-cols-4 gap-2 mb-2.5">
                {presetAmounts.map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => {
                      setAmount(amt);
                      setCustomAmount('');
                    }}
                    className={`py-2 rounded-xl text-sm font-bold border transition-all ${
                      amount === amt && !customAmount
                        ? 'border-[#953914] bg-[#ffefeb] text-[#953914]'
                        : 'border-[#bdc8cb]/60 bg-white text-[#181c20] hover:bg-[#f1f4f9]'
                    }`}
                  >
                    ${amt}
                  </button>
                ))}
              </div>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-[#6e797b]">
                  $
                </span>
                <input
                  type="number"
                  placeholder="Or enter custom amount"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                  }}
                  min="5"
                  className="w-full pl-8 pr-4 py-2 border border-[#bdc8cb] rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>
            </div>

            {/* Donor Information */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Jordan Miller"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Email (for Tax Receipt) *
                </label>
                <input
                  type="email"
                  required
                  placeholder="jordan@example.com"
                  value={donorEmail}
                  onChange={(e) => setDonorEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1.5">
                Payment Channel
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-2.5 rounded-xl border flex items-center justify-center gap-1.5 font-medium ${
                    paymentMethod === 'card'
                      ? 'border-[#005f6a] bg-[#d5f9ff] text-[#005f6a]'
                      : 'border-[#bdc8cb]/60 bg-white text-[#3e494a]'
                  }`}
                >
                  <span className="material-symbols-outlined text-sm">credit_card</span>
                  Card
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('gpay')}
                  className={`p-2.5 rounded-xl border flex items-center justify-center gap-1.5 font-medium ${
                    paymentMethod === 'gpay'
                      ? 'border-[#005f6a] bg-[#d5f9ff] text-[#005f6a]'
                      : 'border-[#bdc8cb]/60 bg-white text-[#3e494a]'
                  }`}
                >
                  <span className="material-symbols-outlined text-sm">account_balance_wallet</span>
                  Google Pay
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank')}
                  className={`p-2.5 rounded-xl border flex items-center justify-center gap-1.5 font-medium ${
                    paymentMethod === 'bank'
                      ? 'border-[#005f6a] bg-[#d5f9ff] text-[#005f6a]'
                      : 'border-[#bdc8cb]/60 bg-white text-[#3e494a]'
                  }`}
                >
                  <span className="material-symbols-outlined text-sm">account_balance</span>
                  Bank ACH
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-full bg-[#953914] text-white font-semibold text-sm hover:bg-[#802a05] shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-2"
              id="confirm-donation-btn"
            >
              <span className="material-symbols-outlined text-sm">lock</span>
              <span>
                Complete ${customAmount ? customAmount : amount} {frequency === 'monthly' ? '/ Month' : ''} Contribution
              </span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

// -------------------- 2. LOGIN MODAL --------------------
interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose }) => {
  const [role, setRole] = useState<'individual' | 'partner' | 'donor' | 'volunteer'>('individual');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
    setTimeout(() => {
      setIsLoggedIn(false);
      onClose();
      alert(`Logged in successfully as ${role.toUpperCase()} user.`);
    }, 900);
  };

  const handleDemoFill = (selectedRole: typeof role) => {
    setRole(selectedRole);
    setEmail(`${selectedRole}@povertyline.org`);
    setPassword('demopass123');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-[#bdc8cb]/50 overflow-hidden">
        <div className="bg-[#f7f9ff] px-6 py-4 border-b border-[#e0e3e8] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#005f6a]">account_circle</span>
            <h3 className="font-heading text-lg font-bold text-[#181c20]">
              Sign In to Poverty Line
            </h3>
          </div>
          <button
            onClick={onClose}
            className="text-[#6e797b] hover:text-[#181c20] p-1 rounded-lg hover:bg-black/5"
          >
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <form onSubmit={handleLogin} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1.5">
              Select Your Portal Role
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { id: 'individual', label: 'Get Help / Member' },
                { id: 'donor', label: 'Donor / Benefactor' },
                { id: 'partner', label: 'Partner Non-profit' },
                { id: 'volunteer', label: 'Active Volunteer' },
              ].map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => setRole(r.id as any)}
                  className={`py-2 px-2.5 rounded-lg border text-center font-medium transition-all ${
                    role === r.id
                      ? 'border-[#005f6a] bg-[#d5f9ff] text-[#005f6a]'
                      : 'border-[#bdc8cb]/60 bg-white text-[#3e494a]'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              Email Address
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@organization.org"
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
            />
          </div>

          {/* Quick Demo Credentials Shortcut */}
          <div className="p-2.5 rounded-lg bg-[#f1f4f9] text-[11px] text-[#3e494a] flex items-center justify-between">
            <span>Quick fill demo:</span>
            <div className="flex gap-1.5">
              <button
                type="button"
                onClick={() => handleDemoFill('partner')}
                className="text-[#005f6a] font-semibold hover:underline"
              >
                Partner
              </button>
              <span>•</span>
              <button
                type="button"
                onClick={() => handleDemoFill('donor')}
                className="text-[#953914] font-semibold hover:underline"
              >
                Donor
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoggedIn}
            className="w-full py-3 rounded-full bg-[#005f6a] text-white font-semibold text-sm hover:bg-[#004f57] shadow-sm transition-all active:scale-[0.98]"
          >
            {isLoggedIn ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
};

// -------------------- 3. LIVE CHAT MODAL --------------------
interface LiveChatModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LiveChatModal: React.FC<LiveChatModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Array<{ sender: 'bot' | 'user'; text: string; time: string }>>([
    {
      sender: 'bot',
      text: 'Hello! I am your 24/7 Poverty Line Support Guide. How can we support you or your family today?',
      time: 'Just now',
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  if (!isOpen) return null;

  const quickPrompts = [
    'Emergency food & pantry locations',
    'Housing vouchers & rent assistance',
    'Applying for open job postings',
    'Healthcare mobile unit schedules',
  ];

  const handleSendMessage = (textToSend: string) => {
    const text = textToSend.trim();
    if (!text) return;

    const userMsg = {
      sender: 'user' as const,
      text,
      time: 'Just now',
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');

    // Responsive assistant reply
    setTimeout(() => {
      let reply = "Thank you for reaching out. We have connected your request to our priority queue. A local coordinator will assist you right here, or you can call our toll-free 24/7 helpline at 1-800-555-0199.";

      const lower = text.toLowerCase();
      if (lower.includes('food') || lower.includes('pantry')) {
        reply = "Our West Side and Central Food Hubs are open today until 8:00 PM. No appointment needed. Free hampers with fresh vegetables, milk, and staple grains are ready for pickup.";
      } else if (lower.includes('housing') || lower.includes('rent')) {
        reply = "Municipal housing vouchers and emergency utility assistance are actively processing. You can request a 15-minute callback from our Family Resource Navigators to help with paperwork.";
      } else if (lower.includes('job') || lower.includes('work')) {
        reply = "We have 4 immediate openings in Community Outreach, Logistics Warehouses, and Clinic Drivers. Check our Job Opportunities section to view requirements and apply in 1 click!";
      } else if (lower.includes('health') || lower.includes('clinic')) {
        reply = "Our Mobile Health Clinic operates Tuesday through Saturday at the Community Transit Hubs providing free checkups, dental triage, and routine prescriptions.";
      }

      setMessages((prev) => [
        ...prev,
        {
          sender: 'bot' as const,
          text: reply,
          time: 'Just now',
        },
      ]);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-[#bdc8cb]/50 flex flex-col h-[560px] overflow-hidden">
        {/* Header */}
        <div className="bg-[#376847] text-white px-6 py-4 flex justify-between items-center shadow-sm">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                <span className="material-symbols-outlined text-white">support_agent</span>
              </div>
              <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-400 border-2 border-[#376847] rounded-full" />
            </div>
            <div>
              <h3 className="font-heading text-base font-bold">Community Care Support</h3>
              <p className="text-xs text-white/80">Active now • Confidential & Free</p>
            </div>
          </div>
          <button onClick={onClose} className="text-white/80 hover:text-white p-1">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        {/* Message Log */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#f7f9ff]">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[82%] px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-[#005f6a] text-white rounded-br-none shadow-sm'
                    : 'bg-white text-[#181c20] border border-[#e0e3e8] rounded-bl-none shadow-sm'
                }`}
              >
                {m.text}
              </div>
              <span className="text-[10px] text-[#6e797b] mt-1 px-1">{m.time}</span>
            </div>
          ))}
        </div>

        {/* Quick Prompts */}
        <div className="px-4 py-2 bg-white border-t border-[#e0e3e8] overflow-x-auto flex gap-1.5 no-scrollbar">
          {quickPrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleSendMessage(prompt)}
              className="text-[11px] whitespace-nowrap bg-[#f1f4f9] hover:bg-[#e0e3e8] text-[#3e494a] px-3 py-1 rounded-full font-medium"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage(inputValue);
          }}
          className="p-3 bg-white border-t border-[#e0e3e8] flex gap-2"
        >
          <input
            type="text"
            placeholder="Type your message..."
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="flex-1 border border-[#bdc8cb] rounded-full px-4 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#376847]"
          />
          <button
            type="submit"
            className="w-10 h-10 rounded-full bg-[#376847] text-white flex items-center justify-center hover:bg-[#2c5339] shadow-sm transition-transform active:scale-95"
          >
            <span className="material-symbols-outlined text-sm">send</span>
          </button>
        </form>
      </div>
    </div>
  );
};

// -------------------- 4. REQUEST CALLBACK MODAL --------------------
interface CallbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CallbackModal: React.FC<CallbackModalProps> = ({ isOpen, onClose }) => {
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [topic, setTopic] = useState('Housing & Shelter');
  const [timeSlot, setTimeSlot] = useState('Within 15 minutes');
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      onClose();
      alert(`Callback booked for ${phone}. A specialist will reach out ${timeSlot}.`);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-[#bdc8cb]/50 overflow-hidden">
        <div className="bg-[#f7f9ff] px-6 py-4 border-b border-[#e0e3e8] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#376847]">phone_callback</span>
            <h3 className="font-heading text-lg font-bold text-[#181c20]">
              Request a Confidential Callback
            </h3>
          </div>
          <button onClick={onClose} className="text-[#6e797b] hover:text-[#181c20] p-1">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <p className="text-xs text-[#3e494a] leading-relaxed">
            Our specialized coordinators provide free, non-judgmental assistance for urgent shelter, food support, utilities, or employment.
          </p>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              Your Preferred Name
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Alex"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#376847]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              Phone Number *
            </label>
            <input
              type="tel"
              required
              placeholder="(555) 000-0000"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#376847]"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              Primary Assistance Topic
            </label>
            <select
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#376847]"
            >
              <option>Housing & Shelter Vouchers</option>
              <option>Emergency Food Assistance</option>
              <option>Job Placements & Resume Help</option>
              <option>Medical Screening & Healthcare</option>
              <option>General Family Support</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              When Should We Call?
            </label>
            <select
              value={timeSlot}
              onChange={(e) => setTimeSlot(e.target.value)}
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#376847]"
            >
              <option>Within 15 minutes (Immediate Queue)</option>
              <option>Today between 1:00 PM - 4:00 PM</option>
              <option>This evening between 6:00 PM - 8:00 PM</option>
              <option>Tomorrow Morning (9:00 AM - 12:00 PM)</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={isSubmitted}
            className="w-full py-3 rounded-full bg-[#376847] text-white font-semibold text-xs sm:text-sm hover:bg-[#2c5339] shadow-sm transition-all active:scale-[0.98]"
          >
            {isSubmitted ? 'Queueing Call...' : 'Confirm Callback'}
          </button>
        </form>
      </div>
    </div>
  );
};

// -------------------- 5. JOB DETAILS & APPLICATION MODAL --------------------
interface JobModalProps {
  job: Job | null;
  onClose: () => void;
}

export const JobDetailsModal: React.FC<JobModalProps> = ({ job, onClose }) => {
  const [applicantName, setApplicantName] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [applied, setApplied] = useState(false);

  if (!job) return null;

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    setApplied(true);
    setTimeout(() => {
      setApplied(false);
      onClose();
      alert(`Application for "${job.title}" submitted! The hiring team will contact you.`);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl border border-[#bdc8cb]/50 overflow-hidden my-8">
        <div className="bg-[#f7f9ff] px-6 py-5 border-b border-[#e0e3e8] flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-[#b6edc2] text-[#3b6d4b]">
                {job.type}
              </span>
              <span className="text-xs text-[#6e797b] flex items-center gap-1">
                <span className="material-symbols-outlined text-xs">location_on</span>
                {job.location}
              </span>
            </div>
            <h3 className="font-heading text-xl font-bold text-[#181c20]">{job.title}</h3>
            <p className="text-xs font-semibold text-[#005f6a] mt-0.5">{job.salary}</p>
          </div>
          <button onClick={onClose} className="text-[#6e797b] hover:text-[#181c20] p-1">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          <div>
            <h4 className="font-heading text-sm font-bold text-[#181c20] uppercase tracking-wider mb-2">
              Role Overview
            </h4>
            <p className="text-sm text-[#3e494a] leading-relaxed">{job.fullDescription}</p>
          </div>

          <div>
            <h4 className="font-heading text-sm font-bold text-[#181c20] uppercase tracking-wider mb-2">
              Key Qualifications & Details
            </h4>
            <ul className="space-y-1.5">
              {job.requirements.map((req, idx) => (
                <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-[#3e494a]">
                  <span className="material-symbols-outlined text-sm text-[#376847] mt-0.5">
                    check_circle
                  </span>
                  <span>{req}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Apply Form */}
          <form onSubmit={handleApply} className="bg-[#f7f9ff] p-4 rounded-xl border border-[#e0e3e8] space-y-3">
            <h4 className="font-heading text-sm font-bold text-[#005f6a] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-sm">send</span>
              Express 1-Click Application
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sam Rivera"
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  className="w-full px-3 py-1.5 border border-[#bdc8cb] rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#181c20] mb-1">
                  Phone / Contact *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="(555) 123-4567"
                  value={applicantPhone}
                  onChange={(e) => setApplicantPhone(e.target.value)}
                  className="w-full px-3 py-1.5 border border-[#bdc8cb] rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1">
                Brief Introduction or Experience
              </label>
              <textarea
                rows={2}
                placeholder="Tell us a little bit about yourself..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full px-3 py-1.5 border border-[#bdc8cb] rounded-lg text-xs bg-white focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              />
            </div>

            <button
              type="submit"
              disabled={applied}
              className="w-full py-2.5 rounded-full bg-[#005f6a] text-white text-xs sm:text-sm font-semibold hover:bg-[#004f57] shadow-sm transition-all"
            >
              {applied ? 'Submitting Application...' : 'Submit Application'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

// -------------------- 6. PARTNER APPLICATION MODAL --------------------
interface PartnerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PartnerApplicationModal: React.FC<PartnerModalProps> = ({ isOpen, onClose }) => {
  const [orgName, setOrgName] = useState('');
  const [contactName, setContactName] = useState('');
  const [email, setEmail] = useState('');
  const [serviceArea, setServiceArea] = useState('Food Security & Pantries');
  const [isDone, setIsDone] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsDone(true);
    setTimeout(() => {
      setIsDone(false);
      onClose();
      alert(`Partner application for ${orgName} submitted. Our logistics team will review within 48 hours.`);
    }, 1000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-[#bdc8cb]/50 overflow-hidden">
        <div className="bg-[#f7f9ff] px-6 py-4 border-b border-[#e0e3e8] flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#005f6a]">domain</span>
            <h3 className="font-heading text-lg font-bold text-[#181c20]">
              Partner Network Application
            </h3>
          </div>
          <button onClick={onClose} className="text-[#6e797b] hover:text-[#181c20] p-1">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <p className="text-xs text-[#3e494a] leading-relaxed">
            Join over 120+ verified community organizations using Poverty Line's real-time logistics and resource routing telemetry.
          </p>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              Organization Name *
            </label>
            <input
              type="text"
              required
              placeholder="e.g. City Harvest Collaborative"
              value={orgName}
              onChange={(e) => setOrgName(e.target.value)}
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1">
                Primary Contact Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Marcus Vance"
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#181c20] mb-1">
                Work Email *
              </label>
              <input
                type="email"
                required
                placeholder="marcus@org.org"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-[#181c20] mb-1">
              Focus Domain
            </label>
            <select
              value={serviceArea}
              onChange={(e) => setServiceArea(e.target.value)}
              className="w-full px-3 py-2 border border-[#bdc8cb] rounded-lg text-xs sm:text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#005f6a]"
            >
              <option>Food Security & Distribution</option>
              <option>Emergency Housing & Shelter</option>
              <option>Healthcare & Mobile Clinics</option>
              <option>Education & Digital Training</option>
              <option>Clean Water Infrastructure</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={isDone}
            className="w-full py-3 rounded-full bg-[#005f6a] text-white font-semibold text-xs sm:text-sm hover:bg-[#004f57] shadow-sm transition-all"
          >
            {isDone ? 'Submitting Application...' : 'Submit Institutional Application'}
          </button>
        </form>
      </div>
    </div>
  );
};

// -------------------- 7. STORY & METHODOLOGY MODALS --------------------
interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle: string;
  content: React.ReactNode;
}

export const InfoModal: React.FC<InfoModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  content,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-[#bdc8cb]/50 overflow-hidden my-8">
        <div className="bg-[#f7f9ff] px-6 py-5 border-b border-[#e0e3e8] flex justify-between items-start">
          <div>
            <h3 className="font-heading text-xl font-bold text-[#181c20]">{title}</h3>
            <p className="text-xs text-[#6e797b] mt-0.5">{subtitle}</p>
          </div>
          <button onClick={onClose} className="text-[#6e797b] hover:text-[#181c20] p-1">
            <span className="material-symbols-outlined">close</span>
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-4 max-h-[70vh] overflow-y-auto text-sm text-[#3e494a] leading-relaxed">
          {content}
        </div>

        <div className="bg-[#f7f9ff] px-6 py-3 border-t border-[#e0e3e8] flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-[#005f6a] text-white text-xs font-semibold rounded-full hover:bg-[#004f57]"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
