import { Job, ForumTopic, Program, LogisticsLog, Testimonial } from '../types';

export const HERO_IMAGES = {
  homeHeroBg: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAM7QZRbc6BL-NaoTqwidJR4fIcJgONob9Cb6cnQ5Stx8d0XLCtojAZ9bs7dYwu4PkxfrAkbd3sXbyu5ufUEZ8yNF36oijZAflOdYzkuehP7HX11rIZUrO3Y01_QbM1rl64Eu-WtI8LD8DQyccceQ5TMeG2WM4nOdFhP4uWNPoAXTvLsdiVxMYZ4SoW1KUp8VfSRER-iU5owika9DQy6AiEvDSTPaZd_qB6KzTmtV5GiwgF6DytGmEwFtxFysSGzSiHwDg',
  sustainableProgress: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDcCOjnHdYtAxBMjihfs7fWKH_gcer2EBTCz0GimzKy9if_He2lmKDePJcPqiIx6cvO4b5_jX2pNYpzZ2nHsBZDUeJ42XFpgZWrgsivAEh8hG5E5ghy4KCJ9RQkj_EnqHFjEVJ7hisiwY2T3LO1gSWUTFH_MGLdFaXFN-BlU3PBW4Ww5pXjrnk6ieVyKORq7e3CGBqbHdQ4f9nSZnxDBMV-cEX6isclTFAaSIfEUvWI63V0CsT5U_UGiA',
  getHelpHero: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBS8KxLdeZE89AwpBOZTFan311ad9_1Vua4c-Jy9NKIeNiaNXsdMKWreYjlaxkf4HaqRYZ9WVC6ymj4FKhraFGqH90d9KfaWK6tZ8q3CSlsNT9TdAng55CA4wgDHaIDyd0YtWBuArhk91691KGvwtHeL2IJ0fdOg4_dFW2OuEsjjPVbnvYwRJbxFqntMqB9mnW1erlQ-UQ94tWERIpQrDTSky2WOgywTeugzqP7hZkmL7iuOyaa8rlDCw',
  donorsHero: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBy3M80B5UbKEYaAg7SzGUdGfva1q6-sb_S_FpyZgCcVzlY3LwQjBEJ6Q2H21Fj6GLhM_2Eh4tS1BdFlkDf-xsfq65T608S7RqIEMbMui4tIA7Cgh5TAFbBN6uBBAZiHIn2VT2xR-TFiQgxW9oAQgu49O8EYBI8ljGOpLllhJkOuJwJ9pkTgqSPmUb0-ES1aLoJzfBTVO3MQXpTqML1MMgfoDV3_J0bGZLYz5UhQyfdA0NgVOwm8nmPpA',
  organisationsHero: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBQJNmYyqmfrTK3mZU8v3plOiXs8dC1HcxKtKIx2mEbU9ykxQE2U-G0TcbBaYMT9GyopcovkYB7txtSoMbQf6AoTvO2B-LpHyrCebD6hhL2YGMYyhZKv7aXjfGolGWBzIZrszc7gcJiGjRa02Y5Qy_w6F-xCt8pgmhOmoe5W7x275-Ct-FrbV6h5W6ImGMPux0JivJ8pWFrlyHd3UP2CoJzfxwyGEbM9SSYZF9TI-KYFm6_TXfpGy90cg',
  sarahJenkins: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBeJHJ_-aoBjtyOPTiamxdQrf6Ed3MNZnQxTjVPsCqCGSmvTwdzuJ6vTpAT2Bf68JPUw2GREcMzSZOhczhHl_TvbW4Umhadl3kc4Oqg6QnXNhOSgeRzUKILmFpSPCgf0uw55zvs8dKl9z2byB41m3emiaQ7X2LpOxI_Hr1XJ2H_Z3YWZGL2b6qom92OoDHLV6xwi5VMcIv9kr1Z2MRpHQK7JNLt8jZCyIKBtJW5W6X39QxnROIc8yoycg',
  davidChen: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAbDhMyguc0is1WjSqeaq73JpQHI5x9UQ2p80f42pAwxoq2BEVoR00BSMEIyINu8HWe4occirS5bZXzozUeD-7Y8ttwwa4F9YWr4Hzsa0Iwa4JF7iqlT80rzJSELnu83nrYu2WpwNi-QDUYFCLSzpfL2lDFVggz1alaH8npd4O1UHWj5TC9iQt67CdAfWTEBNG4w_5MOCFtAMJQQrJ5l-U75zPrD_MoJyF4wAZCmUINrMr5rxg51wB9uA',
};

export const INITIAL_JOBS: Job[] = [
  {
    id: 'job-1',
    title: 'Community Outreach Coordinator',
    type: 'Immediate',
    description: 'Engage with local neighborhoods to distribute resources and facilitate support groups. Full-time position with benefits.',
    fullDescription: 'We are seeking a compassionate, organized Community Outreach Coordinator to join our frontline team. You will lead grassroots neighborhood engagement, coordinate resource pop-ups, facilitate weekly community focus groups, and connect families directly with tailored support services. Comprehensive medical, dental, and transportation stipends provided.',
    location: 'City Center',
    salary: '$24.50 / hr + Benefits',
    requirements: [
      'Strong interpersonal and active listening skills',
      'Familiarity with local community organizations and aid programs',
      'Comfortable conducting field visits and hosting small workshops',
      'Bilingual proficiency (English + Spanish or localized dialect) preferred'
    ],
    postedAt: 'Just now'
  },
  {
    id: 'job-2',
    title: 'Warehouse Associate',
    type: 'Part-time',
    description: 'Assist in organizing and distributing food and essential supplies at our main distribution hub. Flexible hours available.',
    fullDescription: 'Join our logistics distribution center to ensure essential groceries, hygiene kits, and educational packages are sorted, verified, and packed with precision. You will work alongside dedicated team members in a climate-controlled, respectful facility with morning, evening, and weekend shift options.',
    location: 'North District',
    salary: '$20.00 / hr',
    requirements: [
      'Ability to lift up to 35 lbs periodically',
      'Team-oriented attitude with attention to inventory cleanliness',
      'No prior warehouse experience required; comprehensive paid training provided'
    ],
    postedAt: '2 days ago'
  },
  {
    id: 'job-3',
    title: 'Family Resource Navigator',
    type: 'Full-time',
    description: 'Provide individualized guidance for families applying for municipal housing vouchers, childcare subsidies, and emergency utilities aid.',
    fullDescription: 'Our Navigators walk side-by-side with families navigating administrative paperwork and municipal portal systems. You will assist clients from initial intake through voucher approval, maintaining dignified, confidential, and empathetic relationships.',
    location: 'West Metro Center',
    salary: '$26.00 / hr + Health',
    requirements: [
      'Demonstrated experience in case management or social assistance support',
      'Empathetic, non-judgmental communication approach',
      'Proficiency with digital record-keeping and case management portals'
    ],
    postedAt: '3 days ago'
  },
  {
    id: 'job-4',
    title: 'Mobile Health Unit Driver & Aide',
    type: 'Immediate',
    description: 'Safely operate community clinic vans and assist medical teams with patient intake and queue coordination.',
    fullDescription: 'Serve as an indispensable anchor for our traveling health clinics. You will navigate mapped neighborhood routes, set up pop-up triage stations, maintain vehicle safety checks, and welcome neighbors awaiting preventive health and dental checkups.',
    location: 'South District & Mobile Routes',
    salary: '$22.50 / hr',
    requirements: [
      'Valid driver license with clean driving record (Class C or higher)',
      'Basic first aid / CPR certification (or willingness to complete company-paid training)',
      'Warm, friendly demeanor with diverse community members'
    ],
    postedAt: '4 days ago'
  }
];

export const INITIAL_FORUM_TOPICS: ForumTopic[] = [
  {
    id: 'topic-1',
    title: 'Navigating Housing Assistance',
    content: 'Has anyone had experience with the new city voucher program? Looking for tips on the application process and how long the document verification takes.',
    author: 'Sarah M.',
    timeAgo: '2 hours ago',
    category: 'Housing',
    repliesCount: 4,
    likes: 12,
    comments: [
      {
        id: 'c-1',
        author: 'Elena Rostova',
        text: 'The intake appointment went much faster once I had bank statements and utility bills printed in advance. They have free notary services on Thursday mornings!',
        timeAgo: '1 hour ago'
      },
      {
        id: 'c-2',
        author: 'Marcus Vance',
        text: 'Average turnaround was about 10 business days for our family. Definitely check the portal inbox daily for status updates.',
        timeAgo: '45 mins ago'
      }
    ]
  },
  {
    id: 'topic-2',
    title: 'Local Food Pantry Updates',
    content: 'The West Side pantry just extended their hours for working families. They now stay open until 8 PM on Tuesdays and provide fresh produce hampers from community gardens.',
    author: 'David K.',
    timeAgo: '5 hours ago',
    category: 'Food',
    repliesCount: 7,
    likes: 28,
    comments: [
      {
        id: 'c-3',
        author: 'Clara Jenkins',
        text: 'Thank you for sharing this! Do they need advance appointment booking or is walk-in available for the evening hours?',
        timeAgo: '3 hours ago'
      },
      {
        id: 'c-4',
        author: 'David K.',
        text: 'Walk-ins are welcomed! Just bring reusable tote bags if you have them.',
        timeAgo: '2 hours ago'
      }
    ]
  },
  {
    id: 'topic-3',
    title: 'Free Digital Literacy & Computer Classes',
    content: 'Starting next Monday at the Community Hub: evening classes on resume writing, spreadsheet fundamentals, and applying for remote job positions.',
    author: 'Tasha B.',
    timeAgo: '1 day ago',
    category: 'Employment',
    repliesCount: 9,
    likes: 34,
    comments: [
      {
        id: 'c-5',
        author: 'Julian Reed',
        text: 'Is childcare provided during the 6:00 PM session?',
        timeAgo: '18 hours ago'
      },
      {
        id: 'c-6',
        author: 'Tasha B.',
        text: 'Yes! Supervised activities for kids ages 4-11 in the adjoining reading room.',
        timeAgo: '12 hours ago'
      }
    ]
  }
];

export const ACTIVE_PROGRAMS: Program[] = [
  {
    id: 'prog-1',
    title: 'Sustainable Wells Initiative',
    category: 'Clean Water',
    icon: 'water_drop',
    colorType: 'primary',
    description: 'Building community-managed water infrastructure in drought-prone regions to ensure long-term health.',
    fullStory: 'Access to dependable, clean water changes everything: reduces child illness by 64%, enables sustainable communal vegetable cultivation, and restores hours previously spent hauling jerrycans each day.',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBmNSg5zfE7DQ3zu5jpj5Zxxyv-P3AAA9BiSGKYxSlW2irxydJVOEb5SCAVHab0zd0X_NXRgsx9Q3_5x_mQqqm5j33uVZmAjGKZT2aSB0ArTXiTd9-t5i6bne2ufq2LMtQR8jD_hUaYQ6cLisWMt3gahkzoPp5-DMn96ZRgFic6yJOtBbgRS2qVKuJSLP_7jEZwV21k4cKg2og2XK-CdC2-_PmSZwYQWy8nd3Xj-zuvOxoTe9LwT1ChUA',
    imageAlt: 'Clean water gushing into a bucket from community infrastructure',
    goal: 500000,
    raised: 412000,
    impactMetric: '38,000+ people with ongoing access to verified clean water'
  },
  {
    id: 'prog-2',
    title: 'Urban Nutrition Centers',
    category: 'Food Security',
    icon: 'restaurant',
    colorType: 'tertiary',
    description: 'Providing dignified access to nutritious meals through community-led kitchens and local farm partnerships.',
    fullStory: 'We eliminate the stigma of traditional breadlines by transforming food support into warm, community-driven dining hubs and market-style grocery pantries loaded with fresh, culturally relevant produce.',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD_nYDP1xQ8ebU7wdi6mFVIap80ikftYXPIAXzwTBRJfZ_3D9tIu3wAZS0WGnOrYslEHQKUKTtDZkbWObyTwFG6N5EsgaICBCzUhouo0XSHEnnb3ZZm3tEaSrs4LPTJbgF9h8CxZNgpK69HSdFb_CCBWgyxGzTUusU_ugcsTaW18PNOX5MESMrKSR3jUmBfBed3lC9jWjTWBk-y734hWnBuotUaDYQslcmGH5k5vYmy8jQnf5UC_Ijqyg',
    imageAlt: 'Warm community kitchen serving wholesome fresh meals',
    goal: 350000,
    raised: 285000,
    impactMetric: '14,200 nutritious hot meals served every single week'
  },
  {
    id: 'prog-3',
    title: 'Digital Literacy Access',
    category: 'Education',
    icon: 'school',
    colorType: 'secondary',
    description: 'Equipping adults and youth with essential tech skills to bridge the digital divide and open employment pathways.',
    fullStory: 'Providing high-speed broadband hotspots, refurbished laptops, and practical hands-on tutoring covering basic computer skills, cloud collaboration, and career-aligned vocational training.',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDv-4_7XiKvt01r0Aw_OFZxR2Q-vkmIfbyWAKs_S4bOVBD9T7eRbWMa0pa_QdAy9SJaTCBa3Tdw9nP0Ab0AAn7_DErNvG3iphSY-UUXhuWn1po_I3zpPXZQ0Ka35fgsMXT9uHlNMsg_QAgaWY77bJkZOAtSyFaawffzMonEbLjUwMxOhmZsP1SyO1qcB3pZQS0mBk9Pm0t--Qn9QHtgRIco2uIleBcRbi18acrnOKbEyHMzQlDz5_9d1Q',
    imageAlt: 'Adult learners engaged with modern tablets and digital curriculum',
    goal: 250000,
    raised: 198000,
    impactMetric: '1,840 graduates placed in living-wage career pathways'
  },
  {
    id: 'prog-4',
    title: 'Mobile Health Clinics',
    category: 'Healthcare Access',
    icon: 'medical_services',
    colorType: 'tertiary',
    description: 'Bringing essential medical services and health education directly to underserved neighborhoods through our fleet of mobile units.',
    fullStory: 'Our mobile medical units deliver preventive screenings, routine vaccinations, dental checkups, prescription refills, and mental health counseling directly to neighborhood centers and transit hubs.',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD58UOor5Jf6HP23RKceLauPM03eh82qXCZBYAXfvoz1_rK5DNZuv7sv_Bkf2BSJb5Jhpp-M-KSulKhnF0Jq97h0gdeeQyUBlq9_bjAy0-7qtHD1Z68xJ_hfEScK2EDuZZfwnHPT7_PRXP-BuMhNgA9HeEbmyHOFdU99Qd36ct6P28LMtCef7lL1-arjnggsW7klvzzXunsdL5DtMKH4rzs1fSYBH1Sg26MCMqQU7-rOIhZLH-JfeI-WQ',
    imageAlt: 'Modern mobile clinic van delivering care in community',
    goal: 1000000,
    raised: 650000,
    impactMetric: '65% funded • 9,400 clinic visits conducted this year'
  }
];

export const INITIAL_LOGS: LogisticsLog[] = [
  {
    id: 'log-1',
    title: 'Shipment #402 delivered',
    timestamp: '12 mins ago',
    type: 'delivery',
    status: 'completed',
    details: '1,200 kg staple grains and pantry provisions received at Central Hub.'
  },
  {
    id: 'log-2',
    title: 'Low inventory alert: Pantry B',
    timestamp: '34 mins ago',
    type: 'inventory',
    status: 'warning',
    details: 'Baby formula and dry legumes inventory under 15% threshold; replenishment triggered.'
  },
  {
    id: 'log-3',
    title: '5 new volunteers onboarded',
    timestamp: '1 hour ago',
    type: 'volunteer',
    status: 'info',
    details: 'Completed food safety and route-dispatch safety certification.'
  },
  {
    id: 'log-4',
    title: 'Route optimized for Zone A',
    timestamp: '2 hours ago',
    type: 'route',
    status: 'completed',
    details: 'Dynamic routing reduced transit fuel expenditure by 18%.'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't-1',
    quote: 'Integrating with Poverty Line\'s platform allowed us to reduce our resource wastage by 30% in the first quarter. The dashboard provides clarity in high-pressure situations.',
    author: 'Sarah Jenkins',
    role: 'Director of Operations',
    organization: 'FoodForward',
    avatarUrl: HERO_IMAGES.sarahJenkins,
    avatarAlt: 'Sarah Jenkins, Director of Operations, FoodForward'
  },
  {
    id: 't-2',
    quote: 'The onboarding process was incredibly structured. We were able to sync our volunteer database within days and immediately saw an improvement in allocation efficiency.',
    author: 'David Chen',
    role: 'Community Lead',
    organization: 'GlobalCare',
    avatarUrl: HERO_IMAGES.davidChen,
    avatarAlt: 'David Chen, Community Lead, GlobalCare'
  }
];
